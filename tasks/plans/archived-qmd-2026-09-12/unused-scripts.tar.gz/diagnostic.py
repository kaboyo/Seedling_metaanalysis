# python
from pathlib import Path
import re
import pandas as pd

def inspect_taxa(path: str = "taxa.csv", sample_n: int = 10):
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)

    # read with sep/encoding fallback
    df = None
    for enc in ("utf-8", "latin-1"):
        try:
            df = pd.read_csv(p, sep=None, engine="python", dtype=str, encoding=enc)
            break
        except Exception:
            continue
    if df is None:
        df = pd.read_csv(p, sep=",", dtype=str, encoding="utf-8", errors="ignore")

    df = df.fillna("")
    cols = [c for c in df.columns]

    # identify columns
    id_candidates = {"otuid","otu id","feature id","featureid","feature","id","feature_id","#otu id"}
    tax_candidates = {"taxonomy","taxon","taxa","classification","taxonomy_string","lineage"}
    king_candidates = {"kingdom","kingdoms","k"}
    id_col = next((c for c in cols if str(c).strip().lower() in id_candidates), cols[0])
    tax_col = next((c for c in cols if str(c).strip().lower() in tax_candidates), None)
    king_col = next((c for c in cols if str(c).strip().lower() in king_candidates), None)

    # build kingdom series
    def strip_prefix(s: str):
        return re.sub(r'^(k__|d__|D_0__|D_1__|Kingdom:)\s*', '', s or '').strip()

    if king_col:
        kingdom = df[king_col].astype(str).apply(strip_prefix).replace("", pd.NA)
    elif tax_col:
        def first_rank(t: str):
            if not t:
                return pd.NA
            parts = re.split(r'[;|>]\s*', t)
            return strip_prefix(parts[0]) if parts else pd.NA
        kingdom = df[tax_col].astype(str).apply(first_rank).replace("", pd.NA)
    else:
        # attempt to infer from any column containing k__ or D_0__
        inferred = pd.Series([pd.NA] * len(df))
        for c in cols:
            sample = df[c].astype(str).iat[0] if len(df) else ""
            if ("k__" in sample) or ("D_0__" in sample) or (";" in sample and len(sample.split(";"))>1):
                inferred = df[c].astype(str).apply(lambda s: strip_prefix(re.split(r'[;|>]\s*', s)[0]) if s else pd.NA)
                break
        kingdom = inferred.replace("", pd.NA)

    # compute diagnostics
    kingdom_counts = kingdom.value_counts(dropna=False).head(50)
    missing_mask = kingdom.isna()
    diagnostics = {
        "path": str(p),
        "n_rows": df.shape[0],
        "columns": cols,
        "id_col": id_col,
        "tax_col": tax_col,
        "king_col": king_col,
        "n_missing_kingdom": int(missing_mask.sum()),
        "n_unique_kingdoms": int(kingdom.dropna().nunique()),
        "kingdom_counts": kingdom_counts,
        "examples_missing_kingdom": df.loc[missing_mask].head(sample_n),
        "sample_head": df.head(sample_n)
    }
    return diagnostics

# Run and assign to variable 'taxa_diag' so the console shows the returned object
taxa_diag = inspect_taxa("path/from/find.csv")
taxa_diag