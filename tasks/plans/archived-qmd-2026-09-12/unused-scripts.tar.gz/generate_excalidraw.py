#!/usr/bin/env python3
"""
Enhanced Excalidraw generator for WP1-WP4 research workflow figure.
Incorporates botanical detail from Picture 1.png hand-drawn caricatures.
Tight layout (minimal gaps) with large readable fonts and roughness=2 sketch feel.
"""

import json
import uuid
import random

random.seed(42)

ROUGHNESS = 2  # sketchy hand-drawn feel matching original


def uid() -> str:
    return uuid.uuid4().hex[:20]


def rect(
    x: float, y: float, w: float, h: float, *,
    bg: str = "transparent", stroke: str = "#1e1e1e",
    fill: str = "solid", opacity: int = 100,
    rounding: int = 8, stroke_width: int = 2,
    group: str | None = None,
) -> dict:
    return {
        "id": uid(), "type": "rectangle",
        "x": x, "y": y, "width": w, "height": h,
        "angle": 0, "strokeColor": stroke,
        "backgroundColor": bg, "fillStyle": fill,
        "strokeWidth": stroke_width, "strokeStyle": "solid",
        "roughness": ROUGHNESS, "opacity": opacity,
        "roundness": {"type": 3, "value": rounding},
        "seed": random.randint(0, 2**31), "version": 1,
        "isDeleted": False, "boundElements": [],
        "link": None, "locked": False,
        "groupIds": [group] if group else [],
    }


def text(
    x: float, y: float, content: str, *,
    size: int = 20, color: str = "#1e1e1e",
    bold: bool = False, align: str = "center",
    width: float | None = None, group: str | None = None,
) -> dict:
    return {
        "id": uid(), "type": "text",
        "x": x, "y": y,
        "width": width or len(content) * size * 0.55,
        "height": size * 1.35 * max(1, content.count("\n") + 1),
        "angle": 0, "strokeColor": color,
        "backgroundColor": "transparent",
        "fillStyle": "solid", "strokeWidth": 1,
        "strokeStyle": "solid", "roughness": ROUGHNESS,
        "opacity": 100, "roundness": None,
        "seed": random.randint(0, 2**31), "version": 1,
        "isDeleted": False, "boundElements": [],
        "text": content, "fontSize": size,
        "fontFamily": 1, "textAlign": align, "verticalAlign": "middle",
        "containerId": None, "originalText": content,
        "autoResize": True, "lineHeight": 1.25,
        "link": None, "locked": False,
        "groupIds": [group] if group else [],
    }


def arrow(
    x1: float, y1: float, x2: float, y2: float, *,
    color: str = "#1e1e1e", width: int = 2,
    group: str | None = None,
) -> dict:
    return {
        "id": uid(), "type": "arrow",
        "x": x1, "y": y1,
        "width": abs(x2 - x1), "height": abs(y2 - y1),
        "angle": 0, "strokeColor": color,
        "backgroundColor": "transparent",
        "fillStyle": "solid", "strokeWidth": width,
        "strokeStyle": "solid", "roughness": ROUGHNESS,
        "opacity": 100, "roundness": {"type": 2},
        "seed": random.randint(0, 2**31), "version": 1,
        "isDeleted": False, "boundElements": [],
        "points": [[0, 0], [x2 - x1, y2 - y1]],
        "lastCommittedPoint": None,
        "startBinding": None, "endBinding": None,
        "startArrowhead": None, "endArrowhead": "arrow",
        "link": None, "locked": False,
        "groupIds": [group] if group else [],
    }


def ln(
    x1: float, y1: float, x2: float, y2: float, *,
    color: str = "#1e1e1e", width: int = 2,
    style: str = "solid", group: str | None = None,
) -> dict:
    return {
        "id": uid(), "type": "line",
        "x": x1, "y": y1,
        "width": abs(x2 - x1), "height": abs(y2 - y1),
        "angle": 0, "strokeColor": color,
        "backgroundColor": "transparent",
        "fillStyle": "solid", "strokeWidth": width,
        "strokeStyle": style, "roughness": ROUGHNESS,
        "opacity": 100, "roundness": {"type": 2},
        "seed": random.randint(0, 2**31), "version": 1,
        "isDeleted": False, "boundElements": [],
        "points": [[0, 0], [x2 - x1, y2 - y1]],
        "lastCommittedPoint": None,
        "link": None, "locked": False,
        "groupIds": [group] if group else [],
    }


def ell(
    x: float, y: float, w: float, h: float, *,
    bg: str = "transparent", stroke: str = "#1e1e1e",
    fill: str = "solid", opacity: int = 100,
    stroke_width: int = 2, group: str | None = None,
) -> dict:
    return {
        "id": uid(), "type": "ellipse",
        "x": x, "y": y, "width": w, "height": h,
        "angle": 0, "strokeColor": stroke,
        "backgroundColor": bg, "fillStyle": fill,
        "strokeWidth": stroke_width, "strokeStyle": "solid",
        "roughness": ROUGHNESS, "opacity": opacity,
        "roundness": {"type": 2},
        "seed": random.randint(0, 2**31), "version": 1,
        "isDeleted": False, "boundElements": [],
        "link": None, "locked": False,
        "groupIds": [group] if group else [],
    }


# ── Plant drawing helpers ─────────────────────────────────────


def draw_plant(
    cx: float, base_y: float, *,
    height: int = 60, leaf_pairs: int = 3,
    leaf_len: int = 20, leaf_droop: int = 8,
    has_panicle: bool = False, panicle_count: int = 5,
    has_roots: bool = True, root_branches: int = 3,
    stem_color: str = "#4caf50", group: str | None = None,
) -> list[dict]:
    """Draw a detailed rice plant with stem, leaves, optional panicle & roots."""
    els: list[dict] = []
    top_y = base_y - height

    # Main stem
    els.append(ln(cx, base_y, cx, top_y, color=stem_color, width=2, group=group))

    # Leaf pairs along stem
    for i in range(leaf_pairs):
        frac = (i + 1) / (leaf_pairs + 1)
        ly = base_y - height * frac
        ll = leaf_len - i * 2
        dy = -leaf_droop + random.randint(-1, 1)
        # Left leaf
        els.append(ln(cx, ly, cx - ll, ly + dy, color=stem_color, width=1, group=group))
        # Right leaf
        els.append(ln(cx, ly, cx + ll, ly + dy + random.randint(-1, 1),
                       color=stem_color, width=1, group=group))

    # Golden drooping panicle
    if has_panicle:
        # Drooping stem
        els.append(ln(cx, top_y, cx + 10, top_y + 6,
                       color="#b8860b", width=1, group=group))
        for j in range(panicle_count):
            gx = cx + 4 + random.randint(-5, 8)
            gy = top_y + random.randint(-2, 10)
            els.append(ell(gx - 3, gy - 2, 7, 5,
                           bg="#daa520", stroke="#b8860b",
                           stroke_width=1, group=group))

    # Root system
    if has_roots:
        for j in range(root_branches):
            spread = (j / max(root_branches - 1, 1)) * 2 - 1  # -1 to 1
            rdx = int(spread * 10)
            rdy = 8 + random.randint(3, 10)
            els.append(ln(cx, base_y + 2, cx + rdx, base_y + rdy,
                           color="#8b6914", width=1, group=group))

    return els


# ═══════════════════════════════════════════════════════════════
# Collect all elements
# ═══════════════════════════════════════════════════════════════
elements: list[dict] = []

# ── TIGHT dimensions ──────────────────────────────────────────
PW = 340       # panel width (reduced from 380)
PH = 560       # panel height
GAP = 2        # minimal gap between panels
HEADER_H = 62  # header bar height

# ── Panel backgrounds & headers ───────────────────────────────
cfgs = [
    ("WP1: Examining the rice\nspatio-temporal M-gene activity",
     "#fff9ed", "#d4a843"),
    ("WP2: Assessing M gene activity\nacross wild-domesticated rice",
     "#fff9ed", "#d4a843"),
    ("WP3: Deciphering the role of\nM gene-responsive microbiota",
     "#f0f0f0", "#3d3d3d"),
    ("WP4: Examining microbiome-\nenrichment of high M gene active\nrice across environments",
     "#f0ebf5", "#5b4a7a"),
]

for i, (title, bg, hdr) in enumerate(cfgs):
    px = i * (PW + GAP)
    # Panel background
    elements.append(rect(px, 0, PW, PH, bg=bg, stroke="#cccccc",
                         stroke_width=1, rounding=4))
    # Header bar
    elements.append(rect(px + 3, 3, PW - 6, HEADER_H, bg=hdr,
                         stroke=hdr, rounding=6))
    # Header text
    fs = 15 if i < 3 else 13
    elements.append(text(px + 10, 7, title, size=fs,
                         color="#ffffff", bold=True, width=PW - 20))

# Dashed dividers
for i in range(1, 4):
    dx = i * (PW + GAP) - GAP / 2
    elements.append(ln(dx, 0, dx, PH, color="#333333", width=2, style="dashed"))


# ═══════════════════════════════════════════════════════════════
# WP1: Spatio-temporal M-gene activity — FULL SPACE, WELL-FIT
# ═══════════════════════════════════════════════════════════════
wp1_x = 0
wp1_hdr_bot = HEADER_H + 6  # 68 — top boundary for plant content

# Variable spacing: taller plants (top stages) get more vertical room.
# Positions chosen so every plant fits within its band without overflow.
#   Band verification (base_off, height → top, panicle_top, root_bottom):
#   14,18,22 DPF (y=112): base=142, h=70 → top=72, pan≈68, root=158  band[68..177] ✓
#   2,6,10 DPF  (y=242): base=266, h=72 → top=194, pan≈190, root=282 band[177..300] ✓
#   14,18,22 DPG (y=358): base=376, h=58 → top=318, root=392          band[300..409] ✓
#   2,6,10 DPG  (y=460): base=474, h=42 → top=432, root=490          band[409..502] ✓
#   Seed        (y=544): icon ~30px                                    band[502..556] ✓

stages = [
    # (label, y_center, plant_cfg)
    ("Seed",              544, None),
    ("2, 6, & 10 DPG",   460,
     {"height": 42, "leaf_pairs": 2, "leaf_len": 18, "leaf_droop": 6,
      "has_roots": True, "root_branches": 3}),
    ("14, 18, & 22 DPG", 358,
     {"height": 58, "leaf_pairs": 3, "leaf_len": 24, "leaf_droop": 8,
      "has_roots": True, "root_branches": 4}),
    ("2, 6, & 10 DPF",   242,
     {"height": 72, "leaf_pairs": 4, "leaf_len": 28, "leaf_droop": 10,
      "has_panicle": True, "panicle_count": 4,
      "has_roots": True, "root_branches": 4}),
    ("14, 18, & 22 DPF", 112,
     {"height": 70, "leaf_pairs": 5, "leaf_len": 30, "leaf_droop": 10,
      "has_panicle": True, "panicle_count": 6,
      "has_roots": True, "root_branches": 5}),
]

# Base offsets per stage (how far below sy the plant ground sits)
base_offsets = {544: 0, 460: 14, 358: 18, 242: 24, 112: 30}

# Converging bracket from seed fanning up to each stage
seed_anchor_x = wp1_x + 14
seed_anchor_y = stages[0][1] + 14

for label, sy, _ in stages[1:]:
    elements.append(ln(seed_anchor_x, seed_anchor_y,
                       seed_anchor_x + 16, sy + 14,
                       color="#555555", width=2))
    elements.append(ln(seed_anchor_x + 16, sy + 14,
                       wp1_x + 34, sy + 14,
                       color="#555555", width=1))

# Seed horizontal connector
elements.append(ln(seed_anchor_x, seed_anchor_y,
                   wp1_x + 34, seed_anchor_y,
                   color="#555555", width=1))

# Draw each stage
for label, sy, pcfg in stages:
    # Label box
    elements.append(rect(wp1_x + 36, sy - 4, 150, 36, bg="#ffffff",
                         stroke="#999999", stroke_width=1, rounding=5))
    elements.append(text(wp1_x + 42, sy, label, size=15,
                         color="#333333", width=138))

    pcx = wp1_x + 226
    boff = base_offsets[sy]

    if pcfg is None:
        # Seed icon
        elements.append(ell(pcx - 18, sy - 4, 36, 22, bg="#c8a415",
                            stroke="#8b7700", stroke_width=2))
        elements.append(ln(pcx, sy - 4, pcx, sy - 20,
                           color="#7cb342", width=2))
        elements.append(ln(pcx, sy - 14, pcx - 7, sy - 22,
                           color="#7cb342", width=1))
        elements.append(ln(pcx, sy - 14, pcx + 6, sy - 21,
                           color="#7cb342", width=1))
    else:
        elements.extend(draw_plant(pcx, sy + boff, **pcfg))

    # Sampling annotation (all except seed)
    if pcfg is not None:
        elements.append(text(wp1_x + 268, sy - 8, "rhizosphere\nshoots\nsoil",
                             size=12, color="#777777", width=68))


# ═══════════════════════════════════════════════════════════════
# WP2: Wild vs Domesticated rice — FULL SPACE LAYOUT
# ═══════════════════════════════════════════════════════════════
wp2_x = PW + GAP

# Split panel into two halves
wp2_wild_top = 68
wp2_mid = 306     # divider between wild and domesticated
wp2_dom_bot = 554

# ── Wild section (y=68 to y=306, 238px) ──
elements.append(text(wp2_x + 100, wp2_wild_top + 2, "Wild", size=20,
                     color="#555555", bold=True, width=120))

# 3 columns across full width
wp2_col_w = (PW - 8) / 3  # ~110.7px per column

wild_species = [
    ("African wild rice\n(O. barthii)", "#1",
     {"height": 95, "leaf_pairs": 5, "leaf_len": 30, "leaf_droop": 6,
      "stem_color": "#2e7d32"}),
    ("Common wild rice\n(O. rufipogon)", "#2",
     {"height": 80, "leaf_pairs": 4, "leaf_len": 26, "leaf_droop": 8,
      "stem_color": "#388e3c"}),
    ("Indian wild rice\n(O. nivara)", "#2",
     {"height": 60, "leaf_pairs": 3, "leaf_len": 20, "leaf_droop": 10,
      "stem_color": "#558b2f"}),
]

for idx, (name, num, plant_cfg) in enumerate(wild_species):
    cx = wp2_x + 4 + idx * wp2_col_w
    cy = wp2_wild_top + 28
    col_mid = cx + wp2_col_w / 2
    # Number badge (larger)
    elements.append(ell(col_mid - 14, cy, 28, 28, bg="#ffffff", stroke="#333333"))
    elements.append(text(col_mid - 8, cy + 2, num, size=16, color="#333333", width=20))
    # Taller plant
    pcx = col_mid
    pby = cy + 120
    elements.extend(draw_plant(pcx, pby, has_roots=True, root_branches=4,
                               **plant_cfg))
    # Wider salmon label box
    box_w = wp2_col_w - 6
    elements.append(rect(cx, cy + 126, box_w, 56, bg="#f5c6c6",
                         stroke="#cc8888", stroke_width=1, rounding=5))
    elements.append(text(cx + 5, cy + 130, name, size=13,
                         color="#333333", width=box_w - 10))

# Subtle divider line between wild and domesticated
elements.append(ln(wp2_x + 20, wp2_mid - 4, wp2_x + PW - 20, wp2_mid - 4,
                   color="#cccccc", width=1, style="dashed"))

# ── Domesticated section (y=306 to y=554, 248px) ──
elements.append(text(wp2_x + 60, wp2_mid + 2, "Domesticated", size=20,
                     color="#555555", bold=True, width=200))

dom_species = [
    ("African domesticated\nrice (O. glaberrima)", "#3",
     {"height": 80, "leaf_pairs": 4, "leaf_len": 24, "leaf_droop": 8,
      "stem_color": "#43a047", "has_panicle": True, "panicle_count": 5}),
    ("Asian domesticated\nrice (O. sativa L.\nssp. japonica)", "#3",
     {"height": 90, "leaf_pairs": 4, "leaf_len": 26, "leaf_droop": 8,
      "stem_color": "#43a047", "has_panicle": True, "panicle_count": 6}),
    ("Asian domesticated\nrice (O. sativa L.\nssp. indica)", "#3",
     {"height": 80, "leaf_pairs": 4, "leaf_len": 22, "leaf_droop": 9,
      "stem_color": "#43a047", "has_panicle": True, "panicle_count": 5}),
]

for idx, (name, num, plant_cfg) in enumerate(dom_species):
    cx = wp2_x + 4 + idx * wp2_col_w
    cy = wp2_mid + 28
    col_mid = cx + wp2_col_w / 2
    # Badge (larger)
    elements.append(ell(col_mid - 14, cy, 28, 28, bg="#ffffff", stroke="#333333"))
    elements.append(text(col_mid - 8, cy + 2, num, size=16, color="#333333", width=20))
    # Taller plant with golden panicles
    pcx = col_mid
    pby = cy + 120
    elements.extend(draw_plant(pcx, pby, has_roots=True, root_branches=4,
                               **plant_cfg))
    # Wider darker pink label box
    box_w = wp2_col_w - 6
    box_h = 66 if idx > 0 else 56
    elements.append(rect(cx, cy + 126, box_w, box_h, bg="#e8a0a0",
                         stroke="#cc8888", stroke_width=1, rounding=5))
    elements.append(text(cx + 5, cy + 130, name, size=12,
                         color="#333333", width=box_w - 10))


# ═══════════════════════════════════════════════════════════════
# WP3: Deciphering the role of M gene-responsive microbiota
# (Infographic style inspired by WP3_infographic.png)
# ═══════════════════════════════════════════════════════════════
wp3_x = 2 * (PW + GAP)
wp3_cx = wp3_x + PW / 2

# ── 4 Petri dishes with double-ring outline and colorful colonies ──
colony_colors = ["#e64a19", "#1e88e5", "#43a047", "#fdd835",
                 "#8e24aa", "#00acc1", "#ff7043", "#5c6bc0"]

for dish_i in range(4):
    dx = wp3_x + 14 + dish_i * 80
    dy = 78
    # Outer ring
    elements.append(ell(dx - 2, dy - 2, 72, 52, bg="transparent",
                        stroke="#555555", stroke_width=2))
    # Inner dish
    elements.append(ell(dx + 2, dy + 2, 64, 44, bg="#faf8f0", stroke="#aaaaaa"))
    # Colony dots (10 per dish, varied sizes)
    for _ in range(10):
        cx_dot = dx + 8 + random.randint(0, 48)
        cy_dot = dy + 8 + random.randint(0, 28)
        sz = random.choice([6, 7, 8, 9])
        col = random.choice(colony_colors)
        elements.append(ell(cx_dot, cy_dot, sz, sz, bg=col, stroke=col,
                            stroke_width=0))

# Bold arrow down
elements.append(arrow(wp3_cx, 138, wp3_cx, 158, color="#555555", width=2))

# ═════════════════════════════════════════════
# INFOGRAPHIC 1: SynCom Screening
# ═════════════════════════════════════════════
syncom_y = 164
syncom_h = 150
elements.append(rect(wp3_x + 8, syncom_y, PW - 16, syncom_h, bg="#fdfcf8",
                     stroke="#888888", rounding=14))

# ── Erlenmeyer flask (larger, matching infographic) ──
fx = wp3_x + 28
fy = syncom_y + 12
# Flask neck
elements.append(ln(fx + 18, fy, fx + 28, fy, color="#555555", width=2))
elements.append(ln(fx + 18, fy, fx + 18, fy + 20, color="#555555", width=2))
elements.append(ln(fx + 28, fy, fx + 28, fy + 20, color="#555555", width=2))
# Flask body (widens)
elements.append(ln(fx + 18, fy + 20, fx, fy + 56, color="#555555", width=2))
elements.append(ln(fx + 28, fy + 20, fx + 46, fy + 56, color="#555555", width=2))
elements.append(ln(fx, fy + 56, fx + 46, fy + 56, color="#555555", width=2))
# Liquid fill
elements.append(rect(fx + 5, fy + 36, 36, 18, bg="#c5e1a5", stroke="#c5e1a5",
                     stroke_width=0, rounding=2, opacity=60))
# Metabolite dots inside flask
for mx, my in [(10, 38), (22, 42), (34, 40), (16, 48), (28, 50), (20, 34)]:
    col = random.choice(["#e64a19", "#43a047", "#fdd835", "#8e24aa", "#1e88e5"])
    elements.append(ell(fx + mx, fy + my, 7, 7, bg=col, stroke=col, stroke_width=0))

# "Metabolites" label with curved arrow
elements.append(text(fx + 50, fy + 8, "Metabolites",
                     size=12, color="#666666", width=80))
elements.append(arrow(fx + 52, fy + 24, fx + 90, fy + 24, color="#888888", width=1))

# ── Diverse bacteria cluster (rods + cocci, matching infographic) ──
bx = wp3_x + 175
by = syncom_y + 14
bacteria_data = [
    # (dx, dy, w, h, color) - mix of rods and round
    (0, 0, 20, 8, "#43a047"),    # green rod
    (24, 6, 8, 8, "#fdd835"),    # yellow coccus
    (10, 14, 18, 7, "#1e88e5"),  # blue rod
    (32, 16, 22, 8, "#e64a19"),  # red rod
    (5, 26, 8, 8, "#8e24aa"),    # purple coccus
    (22, 28, 20, 7, "#ff7043"),  # orange rod
    (42, 4, 7, 7, "#00acc1"),    # teal coccus
    (38, 30, 18, 7, "#43a047"),  # green rod
    (0, 38, 20, 8, "#1e88e5"),   # blue rod
    (26, 42, 8, 8, "#fdd835"),   # yellow coccus
]
for bdx, bdy, bw, bh, bc in bacteria_data:
    elements.append(ell(bx + bdx, by + bdy, bw, bh, bg=bc, stroke=bc,
                        stroke_width=1, opacity=85))

# Label below
elements.append(text(wp3_x + 22, syncom_y + 74,
                     "Targeted SynCom Screening\nusing M gene regulated\nmetabolites",
                     size=13, color="#444444", width=PW - 44))

# Bold arrow down
elements.append(arrow(wp3_cx, syncom_y + syncom_h + 4, wp3_cx,
                       syncom_y + syncom_h + 22, color="#555555", width=2))

# ═════════════════════════════════════════════
# INFOGRAPHIC 2: Nematode Assay + Metabolomics
# ═════════════════════════════════════════════
nema_y = syncom_y + syncom_h + 28
nema_h = 205
elements.append(rect(wp3_x + 8, nema_y, PW - 16, nema_h, bg="#fdfcf8",
                     stroke="#888888", rounding=14))

# Label
elements.append(text(wp3_x + 16, nema_y + 4,
                     "Nematode screening +\nMetabolomics (LC/MS)\nof filtrate fractions",
                     size=13, color="#444444", width=PW - 32))

# ── Nematode icon (sinuous worm, matching infographic) ──
nx = wp3_x + 20
ny = nema_y + 62
# Thicker worm body with more segments for realistic look
worm_pts = [(0, 12), (10, 2), (22, 14), (34, 4), (46, 16),
            (58, 6), (68, 14)]
for i in range(len(worm_pts) - 1):
    x1, y1 = worm_pts[i]
    x2, y2 = worm_pts[i + 1]
    elements.append(ln(nx + x1, ny + y1, nx + x2, ny + y2,
                       color="#8d6e63", width=3))
# Head
elements.append(ell(nx - 5, ny + 9, 10, 10, bg="#8d6e63", stroke="#5d4037"))
# Tail taper
elements.append(ln(nx + 68, ny + 14, nx + 78, ny + 10,
                   color="#8d6e63", width=2))

# ── Test tubes with colored filtrates ──
tx = wp3_x + 175
ty = nema_y + 56
for ti in range(4):
    ttx = tx + ti * 20
    # Tube body
    elements.append(rect(ttx, ty, 14, 36, bg="#e3f2fd", stroke="#42a5f5",
                         stroke_width=1, rounding=6))
    # Liquid fill
    lev = 12 + random.randint(4, 16)
    lc = random.choice(["#42a5f5", "#7cb342", "#ff7043", "#fdd835"])
    elements.append(rect(ttx + 2, ty + 36 - lev, 10, lev - 2, bg=lc,
                         stroke=lc, stroke_width=0, rounding=3, opacity=70))
# Tube caps
for ti in range(4):
    ttx = tx + ti * 20
    elements.append(rect(ttx + 1, ty - 4, 12, 5, bg="#90a4ae",
                         stroke="#607d8b", stroke_width=1, rounding=2))

# Arrow from nematode+tubes to LC/MS
elements.append(arrow(wp3_cx, nema_y + 100, wp3_cx, nema_y + 112,
                       color="#555555", width=2))

# ── LC/MS machine icon (box with display) ──
lcms_y = nema_y + 118
lcms_x = wp3_x + 20
elements.append(rect(lcms_x, lcms_y, 90, 38, bg="#e3f2fd",
                     stroke="#1e88e5", stroke_width=2, rounding=6))
# Display screen on machine
elements.append(rect(lcms_x + 8, lcms_y + 6, 36, 24, bg="#bbdefb",
                     stroke="#42a5f5", stroke_width=1, rounding=3))
# Small indicator dots
elements.append(ell(lcms_x + 52, lcms_y + 10, 6, 6, bg="#4caf50",
                    stroke="#4caf50", stroke_width=0))
elements.append(ell(lcms_x + 62, lcms_y + 10, 6, 6, bg="#ff7043",
                    stroke="#ff7043", stroke_width=0))
elements.append(text(lcms_x + 50, lcms_y + 20, "LC/MS",
                     size=12, color="#1565c0", bold=True, width=38))

# Arrow to chromatogram
elements.append(arrow(lcms_x + 96, lcms_y + 19, lcms_x + 112, lcms_y + 19,
                       color="#1e88e5"))

# ── Chromatogram peaks (larger, matching infographic style) ──
chrom_x = wp3_x + 140
chrom_y = lcms_y - 2
# Axes
elements.append(ln(chrom_x, chrom_y + 40, chrom_x + 180, chrom_y + 40,
                   color="#888888", width=1))
elements.append(ln(chrom_x, chrom_y + 2, chrom_x, chrom_y + 40,
                   color="#888888", width=1))
# Peaks (line segments)
peaks = [(0, 38), (10, 34), (20, 18), (28, 6), (36, 16), (46, 34),
         (56, 28), (66, 8), (74, 4), (82, 12), (92, 30), (102, 36),
         (112, 22), (122, 10), (132, 18), (142, 32), (155, 36), (170, 38)]
for i in range(len(peaks) - 1):
    x1, y1 = peaks[i]
    x2, y2 = peaks[i + 1]
    elements.append(ln(chrom_x + x1, chrom_y + y1, chrom_x + x2, chrom_y + y2,
                       color="#1e88e5", width=2))


# ═══════════════════════════════════════════════════════════════
# WP4: Microbiome-enrichment across environments (6 soil types)
# MAXIMISED LAYOUT — fills entire 340×560 panel
# ═══════════════════════════════════════════════════════════════
wp4_x = 3 * (PW + GAP)
wp4_cx = wp4_x + PW / 2
PURPLE = "#5b4a7a"

# Vibrant, maximally distinct colour palette
env_data = [
    ("Soil 1", "#1565c0", "#bbdefb"),   # deep blue
    ("Soil 2", "#2e7d32", "#c8e6c9"),   # vivid green
    ("Soil 3", "#ff8f00", "#ffecb3"),   # rich amber
    ("Soil 4", "#6a1b9a", "#e1bee7"),   # deep purple
    ("Soil 5", "#c62828", "#ffcdd2"),   # crimson
    ("Soil 6", "#00695c", "#b2dfdb"),   # dark teal
]

# ── ROW 1: Soil types — full width, larger blocks ──
soil_margin = 2  # margin from panel edge
usable_w = PW - 2 * soil_margin  # 336px
soil_spacing = usable_w / 6  # 56px each
soil_block_w = 50
soil_block_h = 44
soil_row_y = 70  # start right below header

for idx, (label, color, bg_col) in enumerate(env_data):
    ex = wp4_x + soil_margin + idx * soil_spacing + (soil_spacing - soil_block_w) / 2
    ey = soil_row_y

    # Soil block (bigger)
    elements.append(rect(ex, ey + 30, soil_block_w, soil_block_h, bg=bg_col,
                         stroke=color, stroke_width=2, rounding=3))
    # Texture marks (unique per soil)
    if idx == 0:  # horizontal layers
        for ly_off in [12, 24, 36]:
            elements.append(ln(ex + 5, ey + 30 + ly_off, ex + 45, ey + 30 + ly_off,
                               color=color, width=1))
    elif idx == 1:  # dots
        for sx, sy_d in [(10, 8), (26, 18), (40, 10), (18, 32), (34, 28)]:
            elements.append(ell(ex + sx, ey + 30 + sy_d, 5, 5, bg=color,
                                stroke=color, stroke_width=0, opacity=50))
    elif idx == 2:  # diagonal hatching
        for d in range(3):
            elements.append(ln(ex + 6 + d * 16, ey + 32, ex + 14 + d * 16, ey + 70,
                               color=color, width=1))
    elif idx == 3:  # cross pattern
        elements.append(ln(ex + 8, ey + 38, ex + 42, ey + 66,
                           color=color, width=1))
        elements.append(ln(ex + 42, ey + 38, ex + 8, ey + 66,
                           color=color, width=1))
    elif idx == 4:  # stipple circles
        for sx, sy_d in [(12, 10), (30, 14), (20, 28), (38, 30), (10, 36)]:
            elements.append(ell(ex + sx, ey + 30 + sy_d, 7, 7, bg="transparent",
                                stroke=color, stroke_width=1, opacity=50))
    else:  # wavy lines
        for ly_off in [10, 22, 34]:
            elements.append(ln(ex + 4, ey + 30 + ly_off, ex + 24, ey + 32 + ly_off,
                               color=color, width=1))
            elements.append(ln(ex + 24, ey + 32 + ly_off, ex + 46, ey + 30 + ly_off,
                               color=color, width=1))

    # Taller rice plant coloured to match soil type
    pcx = ex + soil_block_w / 2
    pcy = ey + 30
    plant_h = 32
    elements.append(ln(pcx, pcy, pcx, pcy - plant_h, color=color, width=2))
    # 3 leaf pairs
    for lp in range(3):
        ly = pcy - 6 - lp * 9
        ll = 12 - lp * 2
        elements.append(ln(pcx, ly, pcx - ll, ly - 5, color=color, width=1))
        elements.append(ln(pcx, ly, pcx + ll, ly - 4, color=color, width=1))
    # Colour-matched roots
    elements.append(ln(pcx, pcy + 2, pcx - 6, pcy + 14, color=color, width=1))
    elements.append(ln(pcx, pcy + 2, pcx + 6, pcy + 14, color=color, width=1))
    elements.append(ln(pcx, pcy + 2, pcx, pcy + 16, color=color, width=1))

    # Label below block
    elements.append(text(ex - 1, ey + 78, label, size=12,
                         color=color, bold=True, width=soil_block_w + 2))

# ── Converging arrows from each soil to centre ──
arrow_start_y = soil_row_y + 96
arrow_end_y = soil_row_y + 116
for idx in range(6):
    ax_s = wp4_x + soil_margin + idx * soil_spacing + soil_spacing / 2
    elements.append(arrow(ax_s, arrow_start_y, wp4_cx, arrow_end_y,
                          color=env_data[idx][1], width=2))

# ── ROW 2: Sample Collection → Sequencing (wider boxes) ──
row2_y = arrow_end_y + 6
box_h = 46
left_w = 166
right_w = 160
gap_mid = 4

elements.append(rect(wp4_x + 2, row2_y, left_w, box_h, bg="#e8e0f0",
                     stroke=PURPLE, rounding=8))
elements.append(text(wp4_x + 8, row2_y + 4, "Rhizosphere & Soil\nSample Collection",
                     size=15, color=PURPLE, bold=True, width=154))

elements.append(arrow(wp4_x + left_w + 1, row2_y + box_h / 2,
                       wp4_x + left_w + gap_mid + 4, row2_y + box_h / 2,
                       color=PURPLE))

elements.append(rect(wp4_x + left_w + gap_mid + 6, row2_y, right_w, box_h,
                     bg="#d5c8e8", stroke=PURPLE, rounding=8))
elements.append(text(wp4_x + left_w + gap_mid + 12, row2_y + 4,
                     "16S rRNA Amplicon\nSequencing",
                     size=15, color=PURPLE, bold=True, width=148))

# Arrow down
elements.append(arrow(wp4_cx, row2_y + box_h + 2, wp4_cx, row2_y + box_h + 16,
                       color=PURPLE, width=2))

# ── ROW 3: Diversity plots (MAXIMISED height) ──
div_y = row2_y + box_h + 20
div_bottom = PH - 52  # leave room for legend
div_h = div_bottom - div_y  # ~200+ px tall

# Alpha diversity box (left half)
a_x = wp4_x + 2
a_w = PW / 2 - 3  # ~167px
elements.append(rect(a_x, div_y, a_w, div_h, bg="#f8f4fc",
                     stroke="#9575cd", stroke_width=1, rounding=6))
elements.append(text(a_x + 8, div_y + 4, "Alpha Diversity",
                     size=15, color=PURPLE, bold=True, width=a_w - 16))

# Bar chart — fills the box
chart_top = div_y + 30
chart_bottom = div_y + div_h - 14
chart_h = chart_bottom - chart_top
bar_fractions = [0.72, 0.58, 0.85, 0.65, 0.50, 0.62]  # relative heights
bar_w = (a_w - 30) / 6 - 3  # width per bar
for b_i, frac in enumerate(bar_fractions):
    bc = env_data[b_i][1]
    bh = chart_h * frac
    bx = a_x + 18 + b_i * (bar_w + 3)
    by = chart_bottom - bh
    elements.append(rect(bx, by, bar_w, bh, bg=bc, stroke=bc,
                         stroke_width=0, rounding=2, opacity=90))
# Axes
elements.append(ln(a_x + 12, chart_bottom, a_x + a_w - 6, chart_bottom,
                   color="#888888", width=1))
elements.append(ln(a_x + 12, chart_top - 4, a_x + 12, chart_bottom,
                   color="#888888", width=1))

# Beta diversity box (right half)
b_x = wp4_x + PW / 2 + 1
b_w = PW / 2 - 3  # ~167px
elements.append(rect(b_x, div_y, b_w, div_h, bg="#f8f4fc",
                     stroke="#9575cd", stroke_width=1, rounding=6))
elements.append(text(b_x + 6, div_y + 4, "Beta Diversity\n(PCoA)",
                     size=15, color=PURPLE, bold=True, width=b_w - 12))

# PCoA scatter plot — larger spread, more dots per cluster
pcoa_cx_pos = b_x + b_w / 2
pcoa_cy_pos = div_y + div_h / 2 + 10
spread = min(b_w, div_h) * 0.3  # scale clusters to box size
pcoa_clusters = [
    (env_data[0][1], -0.65, -0.55),
    (env_data[1][1],  0.60,  0.50),
    (env_data[2][1],  0.10, -0.70),
    (env_data[3][1], -0.55,  0.55),
    (env_data[4][1],  0.60, -0.20),
    (env_data[5][1], -0.15,  0.15),
]
random.seed(123)
for col, fx, fy in pcoa_clusters:
    cx_c = pcoa_cx_pos + fx * spread
    cy_c = pcoa_cy_pos + fy * spread
    for _ in range(5):
        ddx = random.randint(-10, 10)
        ddy = random.randint(-8, 8)
        elements.append(ell(cx_c + ddx - 5, cy_c + ddy - 5,
                            10, 10, bg=col, stroke="#ffffff",
                            stroke_width=1, opacity=85))
# Axes
elements.append(ln(b_x + 10, div_y + div_h - 14, b_x + b_w - 6, div_y + div_h - 14,
                   color="#888888", width=1))
elements.append(ln(b_x + 10, div_y + 40, b_x + 10, div_y + div_h - 14,
                   color="#888888", width=1))
elements.append(text(b_x + b_w / 2 - 12, div_y + div_h - 11, "PC1",
                     size=12, color="#888888", width=28))
elements.append(text(b_x - 2, div_y + div_h / 2 + 4, "PC2", size=12,
                     color="#888888", width=28))

# ── Legend (2 rows of 3, spread across full width) ──
leg_y = div_bottom + 8
leg_col_w = PW / 3  # ~113px per column
for row in range(2):
    for col_i in range(3):
        idx = row * 3 + col_i
        lbl, clr, _ = env_data[idx]
        lx = wp4_x + 4 + col_i * leg_col_w
        ly = leg_y + row * 20
        elements.append(ell(lx, ly + 2, 12, 12, bg=clr, stroke=clr, stroke_width=0))
        elements.append(text(lx + 16, ly, lbl, size=12,
                             color="#444444", width=90))


# ═══════════════════════════════════════════════════════════════
# Build Excalidraw document
# ═══════════════════════════════════════════════════════════════
excalidraw_doc = {
    "type": "excalidraw",
    "version": 2,
    "source": "https://excalidraw.com",
    "elements": elements,
    "appState": {
        "gridSize": None,
        "viewBackgroundColor": "#ffffff",
    },
    "files": {},
}

out_path = (
    "/Users/expeditoolimi/Documents/Southampton/Southampton/"
    "Seedling_metaanalysis/WP_figure.excalidraw"
)

with open(out_path, "w") as f:
    json.dump(excalidraw_doc, f, indent=2)

print(f"Excalidraw file saved to: {out_path}")
print(f"Total elements: {len(elements)}")
print(f"Layout: {4 * PW + 3 * GAP}px wide x {PH}px tall")
print(f"Panel width: {PW}px, gap: {GAP}px")
print("Open with: https://excalidraw.com or VS Code Excalidraw extension")
