#!/usr/bin/env python3
"""
Composite the original Picture 1.png (upscaled, cropped to WP1-WP3)
with the AI-generated WP4 panel.
"""

from PIL import Image

ORIG = "/Users/expeditoolimi/Documents/Southampton/Southampton/Seedling_metaanalysis/Picture 1.png"
WP4 = "/Users/expeditoolimi/Documents/Southampton/Southampton/Seedling_metaanalysis/WP4_only.png"
OUT = "/Users/expeditoolimi/Documents/Southampton/Southampton/Seedling_metaanalysis/Picture_1_with_WP4.png"

# --- Load original ---
orig = Image.open(ORIG).convert("RGBA")
print(f"Original size: {orig.size}")

# Crop out the empty WP4 column on the right.
# The original is 4137x1291. WP4 header starts at roughly x=3780.
# Let's keep everything up to and including the WP3 dashed line.
crop_x = 3380  # crop right at WP3 end, fully remove old WP4 stub
orig_cropped = orig.crop((0, 0, crop_x, orig.height))
print(f"Cropped to WP1-WP3: {orig_cropped.size}")

# --- Upscale original 2x for higher resolution ---
scale = 2
orig_up = orig_cropped.resize(
    (orig_cropped.width * scale, orig_cropped.height * scale),
    Image.LANCZOS,
)
print(f"Upscaled WP1-WP3: {orig_up.size}")

# --- Load WP4 panel ---
wp4 = Image.open(WP4).convert("RGBA")
print(f"WP4 panel size: {wp4.size}")

# Resize WP4 to match the height of the upscaled original
target_h = orig_up.height
wp4_ratio = wp4.width / wp4.height
wp4_new_w = int(target_h * wp4_ratio)
wp4_resized = wp4.resize((wp4_new_w, target_h), Image.LANCZOS)
print(f"WP4 resized: {wp4_resized.size}")

# --- Composite side by side ---
total_w = orig_up.width + wp4_resized.width
canvas = Image.new("RGBA", (total_w, target_h), (255, 255, 255, 255))
canvas.paste(orig_up, (0, 0))
canvas.paste(wp4_resized, (orig_up.width, 0))

# Save as high-quality PNG
canvas.save(OUT, "PNG", optimize=True)
print(f"\nFinal composite saved: {OUT}")
print(f"Final size: {canvas.size}")
