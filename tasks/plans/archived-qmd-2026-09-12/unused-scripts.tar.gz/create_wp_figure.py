#!/usr/bin/env python3
"""
Create an improved research workflow figure with WP1-WP4 panels.
Publication-quality, landscape orientation with filled WP4 section.
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch
import matplotlib.patheffects as pe
import numpy as np

# ---------- colour palette ----------
GOLD_HEADER = "#D4A843"
GOLD_HEADER_LIGHT = "#F5E6B8"
DARK_HEADER = "#3D3D3D"
PURPLE_HEADER = "#5B4A7A"
BG_WP1 = "#FFF9ED"
BG_WP2 = "#FFF9ED"
BG_WP3 = "#F0F0F0"
BG_WP4 = "#F0EBF5"
PINK_LABEL = "#F5C6C6"
PINK_LABEL_DARK = "#E8A0A0"
GREEN_ENV = "#7CB342"
BLUE_ENV = "#42A5F5"
BROWN_ENV = "#8D6E63"
COLONY_COLORS = [
    "#E64A19", "#1E88E5", "#43A047", "#FDD835",
    "#8E24AA", "#00ACC1", "#FF7043", "#5C6BC0",
]


def draw_rounded_box(
    ax, x, y, w, h, text, fontsize=7, fc="#FFFFFF", ec="#333333",
    text_color="black", bold=False, alpha=1.0, lw=0.8
):
    """Draw a rounded rectangle with centred text."""
    box = FancyBboxPatch(
        (x, y), w, h,
        boxstyle="round,pad=0.02",
        facecolor=fc, edgecolor=ec, linewidth=lw, alpha=alpha,
        transform=ax.transData, zorder=3,
    )
    ax.add_patch(box)
    weight = "bold" if bold else "normal"
    ax.text(
        x + w / 2, y + h / 2, text,
        ha="center", va="center", fontsize=fontsize,
        fontweight=weight, color=text_color, wrap=True, zorder=4,
    )
    return box


def draw_header(ax, x, y, w, h, text, fc=GOLD_HEADER, fontsize=8.5):
    """Draw a panel header bar."""
    box = FancyBboxPatch(
        (x, y), w, h,
        boxstyle="round,pad=0.01",
        facecolor=fc, edgecolor="black", linewidth=1.2, zorder=5,
    )
    ax.add_patch(box)
    ax.text(
        x + w / 2, y + h / 2, text,
        ha="center", va="center", fontsize=fontsize,
        fontweight="bold", color="white", zorder=6,
        path_effects=[pe.withStroke(linewidth=1.5, foreground="black")],
    )


def draw_rice_plant(ax, cx, cy, scale=1.0, color="#4CAF50", stage="mature"):
    """
    Draw a simplified rice plant icon: vertical stem + diagonal leaf lines.
    No filled polygons. Clean and schematic.
    """
    s = scale * 0.010
    stem_top = cy + 16 * s

    if stage == "seed":
        # just a seed oval, no stem
        ell = mpatches.Ellipse(
            (cx, cy + 2 * s), 5 * s, 3.5 * s, fc="#C8A415", ec="#8B7700", lw=0.8, zorder=4
        )
        ax.add_patch(ell)
        return

    # stem line
    ax.plot([cx, cx], [cy, stem_top], color=color, lw=1.2 * scale, solid_capstyle="round", zorder=3)

    if stage == "seedling":
        # two small leaf lines
        ax.plot(
            [cx, cx - 5 * s], [cy + 8 * s, cy + 12 * s],
            color=color, lw=1.0 * scale, solid_capstyle="round", zorder=3
        )
        ax.plot(
            [cx, cx + 5 * s], [cy + 10 * s, cy + 14 * s],
            color=color, lw=1.0 * scale, solid_capstyle="round", zorder=3
        )
        return

    # mature: two pairs of diagonal leaf lines
    # lower pair
    ax.plot(
        [cx, cx - 7 * s], [cy + 6 * s, cy + 10 * s],
        color=color, lw=1.0 * scale, solid_capstyle="round", zorder=3
    )
    ax.plot(
        [cx, cx + 7 * s], [cy + 6 * s, cy + 10 * s],
        color=color, lw=1.0 * scale, solid_capstyle="round", zorder=3
    )
    # upper pair
    ax.plot(
        [cx, cx - 6 * s], [cy + 11 * s, cy + 15 * s],
        color=color, lw=1.0 * scale, solid_capstyle="round", zorder=3
    )
    ax.plot(
        [cx, cx + 6 * s], [cy + 11 * s, cy + 15 * s],
        color=color, lw=1.0 * scale, solid_capstyle="round", zorder=3
    )

    if stage == "flowering":
        # small panicle dots at the top
        for dx, dy in [(-1.5, 17), (0, 19), (1.5, 17), (0, 17.5)]:
            ax.plot(
                cx + dx * s, cy + dy * s, "o",
                color="#DAA520", markersize=1.8 * scale, zorder=4,
            )

    # small root lines at the base
    for dx in [-3, 0, 3]:
        ax.plot(
            [cx, cx + dx * s], [cy, cy - 3 * s],
            color="#8B6914", lw=0.5 * scale, solid_capstyle="round", zorder=3,
        )


def draw_petri_dish(ax, cx, cy, r=0.035):
    """Draw a petri dish with coloured colonies."""
    dish = mpatches.Ellipse(
        (cx, cy), r * 2, r * 1.6, fc="white", ec="#666666", lw=1.0, zorder=3
    )
    ax.add_patch(dish)
    rng = np.random.RandomState(int(cx * 1000) + int(cy * 1000))
    for _ in range(8):
        dx = rng.uniform(-r * 0.7, r * 0.7)
        dy = rng.uniform(-r * 0.5, r * 0.5)
        col = COLONY_COLORS[rng.randint(len(COLONY_COLORS))]
        dot = mpatches.Circle(
            (cx + dx, cy + dy), r * 0.12, fc=col, ec="none", zorder=4
        )
        ax.add_patch(dot)


def draw_arrow(ax, x1, y1, x2, y2, color="black", lw=1.0, style="->"):
    """Draw a simple arrow."""
    ax.annotate(
        "", xy=(x2, y2), xytext=(x1, y1),
        arrowprops=dict(arrowstyle=style, color=color, lw=lw),
        zorder=5,
    )


def draw_env_icon(ax, cx, cy, w, h, label, bg_color, icon_type):
    """
    Draw a simple rectangular environment icon with colored background
    and a hand-drawn icon shape inside.
    icon_type: 'water', 'greenhouse', or 'sun'
    """
    box = FancyBboxPatch(
        (cx - w / 2, cy - h / 2), w, h,
        boxstyle="round,pad=0.005",
        facecolor=bg_color, edgecolor=bg_color, linewidth=1.5, alpha=0.20, zorder=3,
    )
    ax.add_patch(box)
    # border with full opacity
    border = FancyBboxPatch(
        (cx - w / 2, cy - h / 2), w, h,
        boxstyle="round,pad=0.005",
        facecolor="none", edgecolor=bg_color, linewidth=1.2, alpha=0.7, zorder=3,
    )
    ax.add_patch(border)

    # draw icon shapes
    s = 0.012  # icon scale
    if icon_type == "water":
        # three wavy lines representing water/paddy
        for dy_off in [-0.008, 0.0, 0.008]:
            xs = np.linspace(cx - 1.5 * s, cx + 1.5 * s, 30)
            ys = cy + dy_off + 0.004 * np.sin(8 * np.pi * (xs - cx) / (3 * s))
            ax.plot(xs, ys, color=bg_color, lw=1.2, alpha=0.8, zorder=4)
    elif icon_type == "greenhouse":
        # simple greenhouse shape: rectangle with triangular roof
        gw, gh = 1.5 * s, 1.0 * s
        # walls
        ax.plot(
            [cx - gw / 2, cx - gw / 2, cx + gw / 2, cx + gw / 2],
            [cy - gh / 2, cy + gh / 2, cy + gh / 2, cy - gh / 2],
            color=bg_color, lw=1.2, alpha=0.8, zorder=4,
        )
        # roof
        ax.plot(
            [cx - gw / 2 - 0.002, cx, cx + gw / 2 + 0.002],
            [cy + gh / 2, cy + gh / 2 + 0.8 * s, cy + gh / 2],
            color=bg_color, lw=1.2, alpha=0.8, zorder=4,
        )
    elif icon_type == "sun":
        # circle with rays
        sun = mpatches.Circle(
            (cx, cy), 0.6 * s, fc=bg_color, ec=bg_color, lw=0.8, alpha=0.5, zorder=4
        )
        ax.add_patch(sun)
        for angle in np.linspace(0, 2 * np.pi, 8, endpoint=False):
            x1 = cx + 0.8 * s * np.cos(angle)
            y1 = cy + 0.8 * s * np.sin(angle)
            x2 = cx + 1.3 * s * np.cos(angle)
            y2 = cy + 1.3 * s * np.sin(angle)
            ax.plot([x1, x2], [y1, y2], color=bg_color, lw=1.0, alpha=0.7, zorder=4)

    # label below the box
    ax.text(
        cx, cy - h / 2 - 0.015, label,
        ha="center", va="top", fontsize=6, color="#333333", fontweight="bold",
    )


# ====================== MAIN FIGURE ======================
fig, ax = plt.subplots(1, 1, figsize=(20, 9))
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.axis("off")
fig.patch.set_facecolor("white")

# panel boundaries
panels = [0.0, 0.25, 0.52, 0.76, 1.0]
panel_bgs = [BG_WP1, BG_WP2, BG_WP3, BG_WP4]

# draw backgrounds
for i in range(4):
    rect = mpatches.Rectangle(
        (panels[i], 0), panels[i + 1] - panels[i], 1.0,
        fc=panel_bgs[i], ec="none", zorder=0,
    )
    ax.add_patch(rect)

# dashed vertical dividers
for x in panels[1:-1]:
    ax.axvline(x, color="black", linestyle="--", linewidth=1.5, zorder=2)

# ====================== HEADERS ======================
hdr_h = 0.065
hdr_y = 0.925

draw_header(ax, panels[0] + 0.005, hdr_y, 0.24, hdr_h,
            "WP1: Examining the rice spatio-\ntemporal M-gene activity",
            fc=GOLD_HEADER, fontsize=7.5)
draw_header(ax, panels[1] + 0.005, hdr_y, 0.26, hdr_h,
            "WP2: Assessing M gene activity\nacross wild-domesticated rice",
            fc=GOLD_HEADER, fontsize=7.5)
draw_header(ax, panels[2] + 0.005, hdr_y, 0.23, hdr_h,
            "WP3: Assessing the M gene legacy\nacross host generation",
            fc=DARK_HEADER, fontsize=7.5)
draw_header(ax, panels[3] + 0.005, hdr_y, 0.23, hdr_h,
            "WP4: Examining microbiome-enrichment\nof high M gene active rice\nacross environments",
            fc=PURPLE_HEADER, fontsize=7)

# ====================== WP1 ======================
wp1_cx = 0.145  # plant center x

stages = [
    ("Seed", "seed"),
    ("2, 6, & 10 DPG", "seedling"),
    ("14, 18, & 22 DPG", "mature"),
    ("2, 6, & 10 DPF", "mature"),
    ("14, 18, & 22 DPF", "flowering"),
]

# Evenly distribute 5 stages between y=0.08 and y=0.85
y_bottom = 0.08
y_top = 0.85
stage_ys = np.linspace(y_bottom, y_top, len(stages))

# vertical bracket line — aligned to stage y range
bracket_x = 0.04
ax.plot(
    [bracket_x, bracket_x], [stage_ys[0], stage_ys[-1]],
    color="#555555", lw=1.8, zorder=2,
)
# bracket end caps
for yy in [stage_ys[0], stage_ys[-1]]:
    ax.plot(
        [bracket_x, bracket_x + 0.008], [yy, yy],
        color="#555555", lw=1.8, zorder=2,
    )

for idx, (label, stage) in enumerate(stages):
    yy = stage_ys[idx]
    # draw the plant at the center
    draw_rice_plant(ax, wp1_cx, yy - 0.02, scale=0.9, stage=stage)
    # label box to the left of the plant
    draw_rounded_box(
        ax, 0.055, yy - 0.018, 0.07, 0.035,
        label, fontsize=5.5, fc="#FFFFFFCC", ec="#999999", lw=0.5,
    )
    # tick mark from bracket to label
    ax.plot(
        [bracket_x, 0.055], [yy, yy],
        color="#555555", lw=0.8, zorder=2,
    )

# ====================== WP2 ======================
wp2_left = panels[1] + 0.01
wp2_w = 0.26

# --- Wild rice (top row) ---
wild_species = [
    ("African wild rice\n(O. barthii)", "#1"),
    ("Common wild rice\n(O. rufipogon)", "#2"),
    ("Indian wild rice\n(O. nivara)", "#2"),
]

# "Wild" section label
ax.text(wp2_left + wp2_w / 2, 0.89, "Wild", ha="center", fontsize=8,
        fontstyle="italic", color="#555555")

wild_y_plant = 0.68
wild_y_label = 0.56

for idx, (name, num) in enumerate(wild_species):
    cx = wp2_left + 0.045 + idx * 0.088
    # plant icon
    draw_rice_plant(ax, cx, wild_y_plant, scale=0.7, color="#6B8E23", stage="mature")
    # number badge above plant
    badge_y = wild_y_plant + 0.14
    circ = mpatches.Circle(
        (cx, badge_y), 0.013, fc="white", ec="black", lw=0.8, zorder=5
    )
    ax.add_patch(circ)
    ax.text(cx, badge_y, num, ha="center", va="center", fontsize=5.5,
            fontweight="bold", zorder=6)
    # species label box below plant
    draw_rounded_box(
        ax, cx - 0.04, wild_y_label, 0.08, 0.055,
        name, fontsize=5, fc=PINK_LABEL, ec="#CC8888", lw=0.6,
    )

# --- Domesticated rice (bottom row) ---
dom_species = [
    ("African domesticated\nrice (O. glaberrima)", "#3"),
    ("Asian domesticated rice\n(O. sativa L. ssp.\njaponica)", "#3"),
    ("Asian domesticated rice\n(O. sativa L. ssp.\nindica)", "#3"),
]

# "Domesticated" section label
ax.text(wp2_left + wp2_w / 2, 0.47, "Domesticated", ha="center", fontsize=8,
        fontstyle="italic", color="#555555")

dom_y_plant = 0.24
dom_y_label = 0.06

for idx, (name, num) in enumerate(dom_species):
    cx = wp2_left + 0.045 + idx * 0.088
    # plant icon
    draw_rice_plant(ax, cx, dom_y_plant, scale=0.7, color="#2E7D32", stage="flowering")
    # number badge above plant
    badge_y = dom_y_plant + 0.14
    circ = mpatches.Circle(
        (cx, badge_y), 0.013, fc="white", ec="black", lw=0.8, zorder=5
    )
    ax.add_patch(circ)
    ax.text(cx, badge_y, num, ha="center", va="center", fontsize=5.5,
            fontweight="bold", zorder=6)
    # species label box below plant
    box_h = 0.065 if idx > 0 else 0.055
    draw_rounded_box(
        ax, cx - 0.04, dom_y_label, 0.08, box_h,
        name, fontsize=4.5, fc=PINK_LABEL_DARK, ec="#CC8888", lw=0.6,
    )

# ====================== WP3 ======================
wp3_left = panels[2] + 0.01
wp3_cx = wp3_left + 0.115

# Petri dishes - spaced out more
dish_positions = [
    (wp3_cx - 0.06, 0.80),
    (wp3_cx - 0.02, 0.80),
    (wp3_cx + 0.02, 0.80),
    (wp3_cx + 0.06, 0.80),
]
for dx, dy in dish_positions:
    draw_petri_dish(ax, dx, dy, r=0.022)

# funnel arrow
draw_arrow(ax, wp3_cx, 0.74, wp3_cx, 0.64, color="#444444", lw=1.5)

# SynCom box
draw_rounded_box(
    ax, wp3_cx - 0.09, 0.44, 0.18, 0.18,
    "Targeted SynCom Screening\nusing M gene active\nmetabolites\n(constituted from WP#1B)",
    fontsize=6.5, fc="white", ec="#444444", bold=False,
)

# arrow down
draw_arrow(ax, wp3_cx, 0.42, wp3_cx, 0.32, color="#444444", lw=1.5)

# Nematode box
draw_rounded_box(
    ax, wp3_cx - 0.09, 0.10, 0.18, 0.20,
    "Nematode screening\nagainst SynCom filtrates,\nfollowed by Metabolomics\n(by LC/MS) of\nfiltrate fractions.",
    fontsize=6.5, fc="white", ec="#444444", bold=False, alpha=0.95,
)

# ====================== WP4 (FILLED IN) ======================
wp4_left = panels[3] + 0.01
wp4_w = 0.23
wp4_cx = wp4_left + wp4_w / 2

# --- Row 1: Environment icons (rectangular with colored backgrounds) ---
env_labels = ["Paddy\nfield", "Greenhouse", "Dryland"]
env_colors = [BLUE_ENV, GREEN_ENV, BROWN_ENV]
env_icons = ["water", "greenhouse", "sun"]

# section label
ax.text(
    wp4_cx, 0.89, "Multiple Environments",
    ha="center", fontsize=7.5, fontstyle="italic", color="#5B4A7A",
)

icon_w = 0.055
icon_h = 0.065
for idx, (label, col, icon) in enumerate(zip(env_labels, env_colors, env_icons)):
    cx = wp4_left + 0.04 + idx * 0.075
    cy = 0.80
    draw_env_icon(ax, cx, cy, icon_w, icon_h, label, col, icon)

# arrows down from each environment converging
for idx in range(3):
    cx = wp4_left + 0.04 + idx * 0.075
    # line from each env icon down to a converge point
    ax.annotate(
        "", xy=(wp4_cx, 0.69), xytext=(cx, 0.76),
        arrowprops=dict(
            arrowstyle="-",
            color=env_colors[idx], lw=1.2, linestyle="-",
        ),
        zorder=2,
    )

# main downward arrow from convergence
draw_arrow(ax, wp4_cx, 0.69, wp4_cx, 0.64, color=PURPLE_HEADER, lw=2.0, style="-|>")

# --- Row 2: Sample collection + 16S rRNA sequencing ---
draw_rounded_box(
    ax, wp4_left + 0.005, 0.56, 0.105, 0.075,
    "Root / Soil\nSample\nCollection",
    fontsize=6, fc="#E8E0F0", ec=PURPLE_HEADER, bold=True, lw=0.8,
)
draw_arrow(
    ax, wp4_left + 0.115, 0.597, wp4_left + 0.125, 0.597,
    color=PURPLE_HEADER, lw=1.5, style="-|>",
)
draw_rounded_box(
    ax, wp4_left + 0.125, 0.56, 0.10, 0.075,
    "16S rRNA\nAmplicon\nSequencing",
    fontsize=6, fc="#D5C8E8", ec=PURPLE_HEADER, bold=True, lw=0.8,
)

# arrow down
draw_arrow(ax, wp4_cx, 0.545, wp4_cx, 0.50, color=PURPLE_HEADER, lw=2.0, style="-|>")

# --- Row 3: Diversity Analysis mini-plots ---
# Alpha diversity mini bar chart
bar_x_start = wp4_left + 0.010
bar_y_start = 0.37
bar_w = 0.095
bar_h = 0.105

draw_rounded_box(
    ax, bar_x_start - 0.005, bar_y_start - 0.005, bar_w + 0.01, bar_h + 0.03,
    "", fontsize=5, fc="#F8F4FC", ec="#9575CD", lw=0.8,
)
ax.text(
    bar_x_start + bar_w / 2, bar_y_start + bar_h + 0.015,
    "Alpha Diversity", ha="center", fontsize=6, fontweight="bold", color=PURPLE_HEADER,
)

# mini bars
bar_heights = [0.055, 0.075, 0.040, 0.065, 0.050, 0.060]
bar_colors_list = [BLUE_ENV, BLUE_ENV, GREEN_ENV, GREEN_ENV, BROWN_ENV, BROWN_ENV]
bw = bar_w / (len(bar_heights) + 1)
for i, (bh, bc) in enumerate(zip(bar_heights, bar_colors_list)):
    bx = bar_x_start + (i + 0.5) * bw
    rect = mpatches.Rectangle(
        (bx, bar_y_start + 0.008), bw * 0.75, bh,
        fc=bc, ec="white", lw=0.4, zorder=4, alpha=0.85,
    )
    ax.add_patch(rect)

# Beta diversity PCoA scatter
pcoa_cx = wp4_left + 0.165
pcoa_cy = bar_y_start + bar_h / 2 + 0.01
pcoa_box_w = 0.095

draw_rounded_box(
    ax, pcoa_cx - pcoa_box_w / 2, bar_y_start - 0.005, pcoa_box_w, bar_h + 0.03,
    "", fontsize=5, fc="#F8F4FC", ec="#9575CD", lw=0.8,
)
ax.text(
    pcoa_cx, bar_y_start + bar_h + 0.015,
    "Beta Diversity (PCoA)", ha="center", fontsize=6, fontweight="bold", color=PURPLE_HEADER,
)

# scatter dots grouped by environment
rng = np.random.RandomState(42)
for col, cx_off, cy_off in [
    (BLUE_ENV, -0.015, 0.012),
    (GREEN_ENV, 0.012, -0.012),
    (BROWN_ENV, 0.003, 0.018),
]:
    for _ in range(5):
        dx = cx_off + rng.normal(0, 0.007)
        dy = cy_off + rng.normal(0, 0.005)
        dot = mpatches.Circle(
            (pcoa_cx + dx, pcoa_cy + dy), 0.004,
            fc=col, ec="white", lw=0.3, zorder=5, alpha=0.85,
        )
        ax.add_patch(dot)

# PCoA axes
ax_left = pcoa_cx - 0.035
ax_bottom = pcoa_cy - 0.035
ax.plot(
    [ax_left, pcoa_cx + 0.035], [ax_bottom, ax_bottom],
    color="#888888", lw=0.7, zorder=3,
)
ax.plot(
    [ax_left, ax_left], [ax_bottom, pcoa_cy + 0.035],
    color="#888888", lw=0.7, zorder=3,
)
ax.text(pcoa_cx, ax_bottom - 0.012, "PC1", ha="center", fontsize=5, color="#888888")
ax.text(
    ax_left - 0.008, pcoa_cy, "PC2", ha="center", fontsize=5,
    color="#888888", rotation=90,
)

# arrow down from diversity to meta-analysis
draw_arrow(ax, wp4_cx, 0.355, wp4_cx, 0.305, color=PURPLE_HEADER, lw=2.0, style="-|>")

# --- Row 4: Meta-analysis integration ---
draw_rounded_box(
    ax, wp4_left + 0.02, 0.20, 0.19, 0.10,
    "Cross-Environment\nMeta-Analysis\n& Data Integration",
    fontsize=7, fc="#D1C4E9", ec=PURPLE_HEADER, bold=True, lw=1.0,
)

# arrow down to final output
draw_arrow(ax, wp4_cx, 0.185, wp4_cx, 0.145, color=PURPLE_HEADER, lw=2.0, style="-|>")

# Final output box
draw_rounded_box(
    ax, wp4_left + 0.02, 0.065, 0.19, 0.075,
    "Microbiome Enrichment\nPatterns & Biomarkers",
    fontsize=7, fc=PURPLE_HEADER, ec="black", bold=True,
    text_color="white", lw=1.0,
)

# ====================== LEGEND (WP4 bottom) ======================
legend_y = 0.035
legend_items = [
    (BLUE_ENV, "Paddy field"),
    (GREEN_ENV, "Greenhouse"),
    (BROWN_ENV, "Dryland"),
]
for idx, (col, lab) in enumerate(legend_items):
    lx = wp4_left + 0.035 + idx * 0.075
    circ = mpatches.Circle((lx, legend_y), 0.007, fc=col, ec="white", lw=0.5, zorder=5)
    ax.add_patch(circ)
    ax.text(lx + 0.013, legend_y, lab, va="center", fontsize=5.5, color="#333333")

# ====================== SAVE ======================
out_path = "/Users/expeditoolimi/Documents/Southampton/Southampton/Seedling_metaanalysis/WP_figure_improved.png"
fig.savefig(out_path, dpi=300, bbox_inches="tight", facecolor="white")
plt.close()
print(f"Figure saved to: {out_path}")
