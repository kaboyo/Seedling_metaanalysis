import pandas as pd
import numpy as np
from pathlib import Path

def clean_taxonomy(file_path: Path):
    print(f"Loading taxonomy from {file_path}...")
    # Load with OTUID as index if needed, but for cleaning we can keep it as a column
    df = pd.read_csv(file_path)
    
    # Identify the rank columns in order
    ranks = ["Kingdom", "Phyla", "Class", "Order", "Family", "Genus", "Species"]
    
    # 1. For rows where Kingdom is "Unassigned", label across the row to species
    unassigned_mask = df["Kingdom"].str.strip().str.lower() == "unassigned"
    for rank in ranks[1:]:  # skip Kingdom
        df.loc[unassigned_mask, rank] = "Unassigned"
    
    # 2. For blanks under each rank (Phylum to Species), label "Unassigned_<previous rank identity>"
    # Note: Blanks might be NaN or empty strings
    for i in range(1, len(ranks)):
        current_rank = ranks[i]
        prev_rank = ranks[i-1]
        
        # Define what we consider "blank"
        # Using a mask for NaN or empty string or whitespace-only strings
        is_blank = df[current_rank].isna() | (df[current_rank].astype(str).str.strip() == "")
        
        # Apply the transformation: "Unassigned_<prev_rank_value>"
        # Only if the previous rank is not also blank/unassigned in a way that would be redundant, 
        # but the prompt says specifically: "eg. for blanks under phylum should be labelled 'Unassigned_Bacteria')"
        # We use the values from the previous rank column
        df.loc[is_blank, current_rank] = "Unassigned_" + df.loc[is_blank, prev_rank].astype(str)

    # Save the cleaned taxonomy back to the same file
    print(f"Saving cleaned taxonomy to {file_path}...")
    df.to_csv(file_path, index=False)
    print("Taxonomy cleaning complete.")

if __name__ == "__main__":
    taxa_path = Path("Datesets/taxa.csv")
    if taxa_path.exists():
        clean_taxonomy(taxa_path)
    else:
        print(f"Error: {taxa_path} not found.")
