#!/usr/bin/env python3
"""Try generating with minimal tokens to fit within credit budget."""

import base64
import json
import os
import requests
from pathlib import Path

API_KEY = os.getenv(
    "OPENROUTER_API_KEY",
    "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",
)

# Very short prompt to minimize input tokens
SHORT_PROMPT = (
    "Scientific workflow diagram, 4 panels left-to-right: "
    "WP1 rice growth stages, WP2 wild vs domesticated rice species, "
    "WP3 microbiome SynCom screening, WP4 cross-environment meta-analysis. "
    "Professional, clean, labeled."
)

payload = {
    "model": "google/gemini-3.1-flash-image-preview",
    "messages": [{"role": "user", "content": SHORT_PROMPT}],
    "modalities": ["image", "text"],
    "max_tokens": 4096,  # cap output to fit budget
}

headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json",
}

print(f"Sending request with max_tokens=4096...")
print(f"Prompt length: {len(SHORT_PROMPT)} chars")

resp = requests.post(
    "https://openrouter.ai/api/v1/chat/completions",
    headers=headers,
    json=payload,
    timeout=120,
)

print(f"HTTP {resp.status_code}")

try:
    data = resp.json()
except Exception:
    print(f"Raw response: {resp.text[:500]}")
    raise

if resp.status_code != 200:
    print(f"Error: {json.dumps(data, indent=2)}")
else:
    # Try to extract image
    choices = data.get("choices", [])
    if choices:
        msg = choices[0].get("message", {})
        images = msg.get("images", [])
        if images:
            first = images[0]
            if isinstance(first, dict) and first.get("type") == "image_url":
                url = first.get("image_url", {})
                if isinstance(url, dict):
                    url = url.get("url", "")
                if url and "," in url:
                    b64 = url.split(",", 1)[1]
                    img_bytes = base64.b64decode(b64)
                    out = Path(
                        "/Users/expeditoolimi/Documents/Southampton/Southampton/"
                        "Seedling_metaanalysis/WP_figure_AI.png"
                    )
                    out.write_bytes(img_bytes)
                    print(f"Image saved to {out} ({len(img_bytes)} bytes)")
                else:
                    print("Image URL format unexpected")
            else:
                print(f"Image format unexpected: {type(first)}")
        else:
            content = msg.get("content", "")
            print(f"No images field. Content type: {type(content)}")
            if isinstance(content, str):
                print(f"Content preview: {content[:300]}")
    print(f"\nUsage: {data.get('usage', 'N/A')}")
