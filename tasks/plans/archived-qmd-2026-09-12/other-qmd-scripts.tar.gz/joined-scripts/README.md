## Joined Scripts

This directory consolidates the notebooks that were previously split between
`EXC_16S_FOE_KOB/` and `strawberry-data-Excalibur/`.

### Analysis Classes

- `beta-diversity/`
  - `Beta-diversity.qmd`: canonical beta-diversity notebook based on the richer strawberry variant.
  - `Beta-diversity_EXC.qmd`: EXC-specific beta-diversity variant kept for comparison.
  - `Beta-diversity_functions.qmd`: canonical functional beta-diversity helper notebook.
  - `Beta-diversity_functions_data_variant.qmd`: alternate helper notebook that expects files under `Data/`.

- `diversity-analysis/`
  - `diversity-analysis.qmd`: canonical all-variables diversity notebook.
  - `diversity-analysis_core.qmd`: reduced/core diversity-analysis variant.
  - `diversity-analysis_strawberry.qmd`: strawberry-specific diversity-analysis variant.
  - `diversity-analysis_qwen.qmd`: Qwen-generated diversity-analysis variant.
  - `diversity-analysis_modified.qmd`: management-focused diversity-analysis variant.
  - `diversity-analysis_jaccard.qmd`: canonical Jaccard-focused diversity notebook.

- `project/`
  - `strawberry-excalibur.qmd`: primary end-to-end project notebook based on the shorter EXC workflow.
  - `strawberry-excalibur_EXC.qmd`: EXC legacy project notebook.
  - `strawberry-excalibur_phyloseq-legacy.qmd`: legacy phyloseq-object project notebook.

- `reports/`
  - Supporting report/manuscript notebooks retained from the strawberry set.

### Notes

- Exact duplicates were collapsed during the merge.
- Distinct variants were retained when they contained materially different logic,
  file conventions, or reporting scope.
- The canonical notebooks under `project/`, `beta-diversity/`, and
  `diversity-analysis/` are now adapted to the local `Datesets/metadata.csv`
  schema and use the available variables such as `Author`, `Geography`,
  `Cultivar`, `Developmental_Stage`, `Scientific_Name`, `sample_description`,
  `Title`, and `study_alias`.
- Legacy comparison variants still exist, but they may still reference the
  original strawberry/EXC variable names and should be treated as archival.
