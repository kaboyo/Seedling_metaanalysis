#!/usr/bin/env Rscript
# Taxonomic composition strips, split by cultivar and stage, faceted by study.
#
#   Rscript tools/taxa_strip_by_study_prototype.R [rank]      # phylum (default) | family | genus
#
# This is the per-study view the pooled strips cannot give. Pooling all 1,886 samples
# makes the composition mostly a description of PRJEB45079, which contributes 72% of
# them; faceting by study shows whether a seed-to-seedling shift is a general pattern
# or one study's result.
#
# Abundances are the MEAN OF PER-SAMPLE relative abundances within each cultivar x
# stage, so every sample carries equal weight. Summing counts first would let the
# deepest-sequenced samples dominate a strip.

suppressPackageStartupMessages({
    library(phyloseq); library(ggplot2); library(dplyr); library(tidyr)
    library(stringr); library(forcats); library(scales); library(ggtext)
})

args <- commandArgs(trailingOnly = TRUE)
RANK <- if (length(args)) args[1] else "phylum"
RANK_COL <- c(phylum = "Phyla", family = "Family", genus = "Genus")[[RANK]]
TOP_N <- if (RANK == "phylum") 6 else 10
NAT_FONT <- "Helvetica"

npg <- c("#E64B35", "#4DBBD5", "#00A087", "#3C5488", "#F39B7F", "#8491B4",
         "#E6AB02", "#7570B3", "#66A61E", "#B09C85", "#DC0000", "#91D1C2")

ps <- readRDS("analysis_results/setup/ps_clean.rds")
md <- as(sample_data(ps), "data.frame"); md$sample_id <- rownames(md)
tax <- as.data.frame(tax_table(ps), stringsAsFactors = FALSE)

# Per-sample relative abundance, collapsed to the requested rank.
otu <- as(otu_table(ps), "matrix")
if (!taxa_are_rows(ps)) otu <- t(otu)               # features x samples

# Three samples have zero total counts and therefore no composition at all. Left in,
# they contribute a column of zeros that drags each strip mean below 100% (PRJNA649549
# came out at 52/54 = 96.3%). They are the same three samples for which Shannon is
# undefined and which break DESeq2 size factors - drop them here too.
depth <- colSums(otu)
n_zero <- sum(depth == 0)
if (n_zero > 0) {
    cat("dropping", n_zero, "zero-count sample(s) with no composition\n")
    otu <- otu[, depth > 0, drop = FALSE]
    depth <- depth[depth > 0]
}
rel <- sweep(otu, 2, depth, "/")

rank_of <- tax[[RANK_COL]]
rank_of[is.na(rank_of) | rank_of == "" | str_detect(rank_of, "^unassigned")] <- "Unassigned"
agg <- rowsum(rel, group = rank_of)                 # rank x samples

long <- as.data.frame(as.table(agg), stringsAsFactors = FALSE) |>
    setNames(c("Taxon", "sample_id", "rel")) |>
    left_join(md |> select(sample_id, study_alias, Cultivar, Developmental_Stage),
              by = "sample_id") |>
    # Do not drop samples with no cultivar recorded: PRJNA649549 has none at all, and
    # filtering removed that study from the figure without any indication.
    mutate(Cultivar = ifelse(is.na(Cultivar) | Cultivar == "", "not reported", Cultivar))

# Keep the globally most abundant taxa; everything else becomes "Other" so the
# palette stays readable and comparable across facets.
keep <- long |> summarise(m = mean(rel), .by = Taxon) |>
    arrange(desc(m)) |> slice_head(n = TOP_N) |> pull(Taxon)
keep <- setdiff(keep, "Unassigned")

ref_of <- md |>
    mutate(ref = {
        a <- as.character(Author); bad <- !validUTF8(a)
        a[bad] <- iconv(a[bad], from = "macroman", to = "UTF-8")
        s <- str_replace(a, "^([^_]+).*", "\\1"); y <- str_extract(a, "(19|20)\\d{2}")
        ifelse(is.na(y), s, paste0(s, " et al. ", y))
    }) |>
    summarise(ref = paste(sort(unique(ref)), collapse = "; "), .by = study_alias)

grp <- long |>
    mutate(Taxon = ifelse(Taxon %in% keep, Taxon, "Other")) |>
    summarise(rel = sum(rel), .by = c(sample_id, study_alias, Cultivar,
                                      Developmental_Stage, Taxon)) |>
    # mean across samples within cultivar x stage - equal weight per sample
    summarise(rel = mean(rel), n = n_distinct(sample_id),
              .by = c(study_alias, Cultivar, Developmental_Stage, Taxon))

ord <- c(setdiff(keep, "Other"), "Other")
grp <- grp |> mutate(Taxon = factor(Taxon, levels = ord))

# Strip label carries n: several cultivar x stage cells hold a single sample, where a
# "composition" is one observation rather than an estimate. Flag those explicitly.
strip_n <- grp |> summarise(n = first(n), .by = c(study_alias, Cultivar, Developmental_Stage))
grp <- grp |>
    left_join(strip_n, by = c("study_alias", "Cultivar", "Developmental_Stage"),
              suffix = c("", ".s")) |>
    mutate(stage_lab = ifelse(as.character(Developmental_Stage) == "Seeds",
                              "seed", "seedling"),
           row_lab = sprintf("%s · %s (n=%d)%s", Cultivar, stage_lab,
                             n.s, ifelse(n.s < 3, " *", "")))

# Each strip must sum to ~100%. A duplicate row label would stack two strips together
# and silently double a bar, so assert it rather than trusting the eye.
strip_sums <- grp |> summarise(tot = sum(rel), .by = c(study_alias, row_lab))
bad <- strip_sums |> filter(abs(tot - 1) > 0.02)
if (nrow(bad)) {
    print(as.data.frame(bad))
    stop("strip totals deviate from 100% - likely duplicate row labels")
}

pal <- setNames(rep(npg, length.out = length(ord)), ord)
pal[["Other"]] <- "#B8B8B8"

grp <- grp |>
    left_join(ref_of, by = "study_alias") |>
    mutate(study_lab = paste0(study_alias, "\n", ref))
study_order <- grp |> summarise(n = sum(n.s[!duplicated(row_lab)]), .by = study_lab) |>
    arrange(desc(n)) |> pull(study_lab)
grp$study_lab <- factor(grp$study_lab, levels = study_order)

n_strips <- nrow(strip_n)
p <- ggplot(grp, aes(x = rel, y = row_lab, fill = Taxon)) +
    geom_col(width = 0.78, colour = "white", linewidth = 0.2,
             position = position_stack(reverse = TRUE)) +
    # One merged panel per rank: studies stacked in a single column, each band sized to
    # its number of strips (space = "free_y") so no study is squashed or padded.
    facet_grid(rows = vars(study_lab), scales = "free_y", space = "free_y", switch = "y") +
    scale_fill_manual(values = pal, name = NULL) +
    scale_x_continuous(labels = percent, expand = expansion(mult = c(0, 0.01)),
                       position = "top") +
    labs(x = "Mean relative abundance", y = NULL) +
    guides(fill = guide_legend(nrow = if (RANK == "phylum") 1 else 2, byrow = TRUE,
                               keywidth = unit(11, "pt"), keyheight = unit(11, "pt"))) +
    theme_classic(base_size = 11, base_family = NAT_FONT) +
    theme(strip.placement = "outside",
          strip.background = element_rect(fill = "grey92", colour = NA),
          strip.text.y.left = element_text(angle = 0, hjust = 0, face = "bold",
                                           size = 9.5, family = NAT_FONT,
                                           margin = margin(2, 6, 2, 6)),
          axis.text.y = element_text(size = 8.5, colour = "grey10"),
          axis.text.x = element_text(size = 9.5, colour = "grey30"),
          axis.title.x = element_text(size = 10.5, colour = "grey20"),
          axis.line.y = element_blank(), axis.ticks.y = element_blank(),
          panel.spacing.y = unit(4, "pt"),
          legend.position = "bottom",
          legend.text = element_text(size = 10, colour = "grey15"),
          plot.background = element_rect(fill = "white", colour = NA))

out <- sprintf("analysis_results/figures/fig_taxa_strips_%s.tiff", RANK)
ggsave(out, p, width = 11, height = 1.6 + 0.24 * n_strips, dpi = 300,
       compression = "lzw", bg = "white")

cat(sprintf("\nrank: %s | taxa shown: %d + Other | strips: %d | studies: %d\n",
            RANK, length(keep), nrow(strip_n), n_distinct(grp$study_alias)))
cat(sprintf("strips with n < 3 (single/near-single sample): %d of %d\n",
            sum(strip_n$n < 3), nrow(strip_n)))
cat("wrote", out, "\n")
