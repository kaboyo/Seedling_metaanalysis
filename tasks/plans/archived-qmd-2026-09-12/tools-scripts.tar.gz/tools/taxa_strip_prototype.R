#!/usr/bin/env Rscript
# Replacement for the six circle-packing bubble plots: stacked composition strips.
#
# Why strips beat bubbles here. The bubbles pack circles into a blob, so (i) seeds and
# seedlings sit in two separate figures with no shared baseline, making the very
# comparison the paper is about impossible to read; (ii) circle packing has no
# meaningful axis, so a reader cannot recover a value; and (iii) area judgements are
# systematically less accurate than aligned-length judgements.
#
# Strips fix all three: one aligned bar per stage, segment LENGTH proportional to
# relative abundance, both stages stacked against a common 0-100% axis, and all three
# ranks in one figure instead of six.

suppressPackageStartupMessages({
    library(ggplot2); library(dplyr); library(tidyr); library(readr)
    library(stringr); library(forcats); library(scales); library(patchwork)
})

NAT_FONT <- "Helvetica"
TAB <- "analysis_results/tables"
OUT <- "analysis_results/figures"

# npg-derived categorical ramp, extended for up to ~22 taxa while staying saturated.
# npg core first, then maximally separated hues. Ordered so adjacent ranks in the
# stack never get two reds or two blues side by side.
npg <- c("#E64B35", "#4DBBD5", "#00A087", "#3C5488", "#F39B7F", "#8491B4",
         "#E6AB02", "#7570B3", "#66A61E", "#B09C85", "#DC0000", "#91D1C2",
         "#7E6148", "#E7298A", "#1B9E77", "#D95F02", "#A6761D", "#666666")

read_rank <- function(rank) {
    bind_rows(
        read_csv(file.path(TAB, sprintf("%s_composition_bubble_seeds.csv", rank)),
                 show_col_types = FALSE),
        read_csv(file.path(TAB, sprintf("%s_composition_bubble_seedlings.csv", rank)),
                 show_col_types = FALSE)) |>
        select(Developmental_Stage, Taxon, RelativeAbundance) |>
        mutate(Developmental_Stage = factor(Developmental_Stage,
                                            levels = c("Seedlings", "Seeds")))
}

strip_panel <- function(rank, label_min = 0.04) {
    d <- read_rank(rank)

    # Order taxa by overall abundance so the largest sits at the left of every strip
    # and the eye can track a taxon between the two stages.
    ord <- d |> summarise(tot = sum(RelativeAbundance), .by = Taxon) |>
        arrange(desc(tot)) |> pull(Taxon)
    d <- d |> mutate(Taxon = factor(Taxon, levels = ord))

    pal <- setNames(rep(npg, length.out = nlevels(d$Taxon)), levels(d$Taxon))

    # Label only segments wide enough to hold text; the rest are read from the legend.
    lab <- d |>
        arrange(Developmental_Stage, Taxon) |>
        mutate(pos = cumsum(RelativeAbundance) - RelativeAbundance / 2,
               .by = Developmental_Stage) |>
        filter(RelativeAbundance >= label_min)

    ggplot(d, aes(x = RelativeAbundance, y = Developmental_Stage, fill = Taxon)) +
        geom_col(width = 0.62, colour = "white", linewidth = 0.3,
                 position = position_stack(reverse = TRUE)) +
        geom_text(data = lab,
                  aes(x = pos, y = Developmental_Stage,
                      label = percent(RelativeAbundance, accuracy = 0.1)),
                  inherit.aes = FALSE, size = 2.9, colour = "white",
                  fontface = "bold", family = NAT_FONT) +
        scale_fill_manual(values = pal, name = NULL) +
        scale_x_continuous(labels = percent, expand = expansion(mult = c(0, 0.01))) +
        labs(x = NULL, y = NULL, tag = NULL) +
        guides(fill = guide_legend(nrow = if (rank == "phylum") 2 else 4,
                                   byrow = TRUE, keywidth = unit(9, "pt"),
                                   keyheight = unit(9, "pt"))) +
        theme_classic(base_size = 12, base_family = NAT_FONT) +
        theme(axis.text.y = element_text(size = 12, colour = "grey10", face = "bold"),
              axis.text.x = element_text(size = 10.5, colour = "grey25"),
              axis.line.y = element_blank(), axis.ticks.y = element_blank(),
              legend.position = "bottom",
              legend.text = element_text(size = 9, colour = "grey15"),
              legend.margin = margin(t = -2),
              plot.margin = margin(4, 8, 2, 4))
}

p_phylum <- strip_panel("phylum")
p_family <- strip_panel("family")
p_genus  <- strip_panel("genus")

fig <- (p_phylum / p_family / p_genus) +
    plot_layout(heights = c(1, 1.25, 1.25)) +
    plot_annotation(tag_levels = "a",
        theme = theme(plot.background = element_rect(fill = "white", colour = NA),
                      plot.tag = element_text(face = "bold", size = 16,
                                              family = NAT_FONT)))

ggsave(file.path(OUT, "fig_taxonomic_composition_strips.tiff"), fig,
       width = 11, height = 10, dpi = 300, compression = "lzw", bg = "white")

cat("\n=== composition by rank (what the strips encode) ===\n")
for (r in c("phylum", "family", "genus")) {
    d <- read_rank(r)
    cat(sprintf("\n  %s (%d taxa/stage)\n", r, n_distinct(d$Taxon)))
    top <- d |> arrange(Developmental_Stage, desc(RelativeAbundance)) |>
        slice_head(n = 3, by = Developmental_Stage)
    for (i in seq_len(nrow(top)))
        cat(sprintf("    %-10s %-22s %5.1f%%\n", top$Developmental_Stage[i],
                    top$Taxon[i], 100 * top$RelativeAbundance[i]))
}
cat("\nwrote", file.path(OUT, "fig_taxonomic_composition_strips.tiff"), "\n")
