#!/usr/bin/env Rscript
# Prototype: world map with per-country donut charts.
#
# Why donuts rather than a choropleth fill: a choropleth encodes value by country
# AREA, so France (76.4% of samples) cannot look dominant and Australia (7.5%)
# looks huge. Donut radius scaled on sqrt(n) makes donut AREA proportional to
# sample count, and the ring splits Seeds vs Seedlings - information the current
# map does not carry at all.

suppressPackageStartupMessages({
    library(phyloseq); library(ggplot2); library(dplyr); library(tidyr)
    library(stringr); library(ggforce); library(ggrepel); library(scales)
})

ps <- readRDS("analysis_results/setup/ps_clean.rds")
md <- as(sample_data(ps), "data.frame")

tidy_country <- function(x) str_trim(str_replace(as.character(x), ":.*$", ""))

counts <- md |>
    filter(!is.na(Geography), Geography != "") |>
    mutate(Country = tidy_country(Geography),
           Country = case_when(str_detect(Country, "Korea") ~ "South Korea",
                               .default = Country)) |>
    dplyr::count(Country, Developmental_Stage, name = "n")

totals <- counts |> dplyr::summarise(total = sum(n), .by = Country)

# ── Centroids ────────────────────────────────────────────────────────────────
# A naive mean over all polygons of a country is badly wrong for states with
# distant territories (Alaska drags the USA centroid into the Pacific), so take
# the centroid of each country's LARGEST polygon instead.
world <- map_data("world")
centroids <- world |>
    dplyr::count(region, group, name = "pts") |>
    slice_max(pts, n = 1, by = region) |>
    inner_join(world, by = c("region", "group")) |>
    dplyr::summarise(lon = mean(range(long)), lat = mean(range(lat)), .by = region) |>
    rename(Country = region)

dat <- totals |>
    inner_join(centroids, by = "Country") |>
    # Donut AREA proportional to n: radius scales with sqrt(n).
    mutate(r = 3.2 + 10.5 * sqrt(total / max(total)))

# Western Europe and East Asia are too dense for centroid placement: offset those
# donuts into open space and connect each back to its country with a leader line.
NUDGE <- tibble::tribble(
    ~Country,       ~dx,   ~dy,
    "Denmark",      -8,    20,
    "Italy",         2,   -26,
    "Japan",        26,    -6,
    "South Korea",   4,   -22,
    "New Zealand",  14,   -10
)
dat <- dat |>
    left_join(NUDGE, by = "Country") |>
    mutate(dx = coalesce(dx, 0), dy = coalesce(dy, 0),
           px = lon + dx, py = lat + dy)

missing <- setdiff(totals$Country, centroids$Country)
if (length(missing)) cat("NO CENTROID for:", paste(missing, collapse = ", "), "\n")

# Arc segments: one wedge per stage, per country.
arcs <- counts |>
    inner_join(dat, by = "Country") |>
    arrange(Country, desc(Developmental_Stage)) |>
    mutate(frac = n / total, .by = Country) |>
    mutate(end = 2 * pi * cumsum(frac),
           start = dplyr::lag(end, default = 0), .by = Country)

STAGE <- c(Seeds = "#6159a4", Seedlings = "#feae01")
counts$Developmental_Stage <- factor(counts$Developmental_Stage,
                                     levels = c("Seeds", "Seedlings"))

p <- ggplot() +
    geom_polygon(data = world, aes(long, lat, group = group),
                 fill = "grey93", colour = "white", linewidth = 0.12) +
    geom_segment(data = dat |> filter(dx != 0 | dy != 0),
                 aes(x = lon, y = lat, xend = px, yend = py),
                 colour = "grey45", linewidth = 0.4, linetype = "dotted") +
    geom_point(data = dat |> filter(dx != 0 | dy != 0), aes(lon, lat),
               size = 0.5, colour = "grey45") +
    geom_arc_bar(data = arcs,
                 aes(x0 = px, y0 = py, r0 = r * 0.45, r = r,
                     start = start, end = end, fill = Developmental_Stage),
                 colour = "white", linewidth = 0.2, alpha = 0.95) +
    # Count inside the ring only where it fits; small donuts get it on the label.
    geom_text(data = dat |> filter(r >= 6), aes(px, py, label = comma(total)),
              size = 2.2, fontface = "bold", colour = "grey15") +
    geom_text(data = dat,
              aes(px, py - r - 3.2,
                  label = ifelse(r >= 6, Country, paste0(Country, " (", total, ")"))),
              size = 2.4, colour = "grey25", vjust = 1) +
    scale_fill_manual(values = STAGE, name = NULL) +
    coord_quickmap(ylim = c(-58, 84)) +
    labs(title = "Global distribution of seed and seedling microbiome samples",
         subtitle = sprintf("%s samples, %d countries, %d studies - ring area is proportional to sample count",
                            comma(nrow(md)), nrow(dat), dplyr::n_distinct(md$study_alias)),
         caption = "Ring segments show the seed / seedling split within each country.") +
    theme_void(base_size = 9) +
    theme(plot.background = element_rect(fill = "white", colour = NA),
          panel.background = element_rect(fill = "white", colour = NA),
          legend.text = element_text(size = 9, colour = "grey20"),
          legend.position = "bottom",
          plot.title = element_text(hjust = 0.5, face = "bold", size = 13),
          plot.subtitle = element_text(hjust = 0.5, size = 9, colour = "grey30"),
          plot.caption = element_text(hjust = 0.5, size = 7, colour = "grey45"))

dir.create("analysis_results/figures", showWarnings = FALSE, recursive = TRUE)
ggsave("analysis_results/figures/geographic_distribution_donut_map.tiff", p,
       width = 12, height = 7, dpi = 300, compression = "lzw", bg = "white")

cat("\n=== per-country donuts ===\n")
chk <- dat |> arrange(desc(total)) |>
    mutate(pct = sprintf("%.1f%%", 100 * total / sum(total))) |>
    select(Country, total, pct, lon, lat, r)
for (i in seq_len(nrow(chk))) cat(sprintf("  %-14s %5d  %6s   lon %7.1f  lat %6.1f   r %4.1f\n",
    chk$Country[i], chk$total[i], chk$pct[i], chk$lon[i], chk$lat[i], chk$r[i]))
cat("\nwrote analysis_results/figures/geographic_distribution_donut_map.tiff\n")
