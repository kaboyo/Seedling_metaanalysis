#!/usr/bin/env Rscript
# Measure the two things that dominate this pipeline's runtime, so tuning decisions
# rest on numbers from this machine rather than on general advice.
#
#   Rscript tools/benchmark_performance.R [n_samples]
#
# Run it when nothing else heavy is running - a concurrent render will skew every
# timing here. Default n is 1886, the sample count of the real filtered object.

suppressPackageStartupMessages({
    library(vegan)
})

args <- commandArgs(trailingOnly = TRUE)
n <- if (length(args)) as.integer(args[1]) else 1886L

si <- sessionInfo()
cat("== environment ==\n")
cat("  R         :", R.version.string, "\n")
cat("  platform  :", R.version$platform, "\n")
cat("  BLAS      :", basename(si$BLAS), "\n")
cat("  LAPACK    :", basename(si$LAPACK), "\n")
cat("  physical  :", system("sysctl -n hw.physicalcpu", intern = TRUE), "cores\n")
cat("  logical   :", system("sysctl -n hw.logicalcpu", intern = TRUE), "cores\n")
cat("  detectCores(logical=TRUE):", parallel::detectCores(logical = TRUE), "\n\n")

# ── 1. BLAS-bound work ────────────────────────────────────────────────────────
# betadisper does a full PCoA internally and cmdscale eigendecomposes the whole
# distance matrix, so symmetric eigen at this size is a direct proxy for a large
# slice of the pipeline's cost. The reference libRblas is single-threaded;
# libRblas.vecLib.dylib (Apple Accelerate) is multithreaded and ships with R.
cat("== 1. symmetric eigendecomposition,", n, "x", n, "==\n")
set.seed(1)
m <- crossprod(matrix(rnorm(n * 200), nrow = 200))
t_eigen <- system.time(eigen(m, symmetric = TRUE, only.values = TRUE))[["elapsed"]]
cat(sprintf("  eigen(): %.1f s\n", t_eigen))
cat(sprintf("  matrix multiply %dx%d: %.1f s\n\n", n, n,
            system.time(m %*% m)[["elapsed"]]))

# ── 2. Permutation tests at varying thread counts ─────────────────────────────
# adonis2 and permutest take `parallel =`. More threads is not automatically
# faster: the 8 logical cores here are 4 physical cores with hyperthreading, and
# these permutations are memory-bandwidth bound.
cat("== 2. adonis2, 999 permutations, by thread count ==\n")
set.seed(1)
comm <- matrix(rpois(n * 100, 3), nrow = n)
grp <- factor(sample(c("Seeds", "Seedlings"), n, replace = TRUE))
d <- vegdist(comm, method = "bray")
df <- data.frame(group = grp)

for (th in unique(c(1L, 2L, 4L, parallel::detectCores(logical = TRUE) - 1L))) {
    set.seed(123)
    el <- system.time(
        vegan::adonis2(d ~ group, data = df, permutations = 999, parallel = th)
    )[["elapsed"]]
    cat(sprintf("  parallel = %-2d : %6.1f s\n", th, el))
}

cat("\n== how to act on this ==\n")
cat("  * If BLAS is libRblas.0.dylib, switch to Apple Accelerate and re-run:\n")
cat("      cd /Library/Frameworks/R.framework/Resources/lib\n")
cat("      ln -sf libRblas.vecLib.dylib libRblas.dylib\n")
cat("    Revert with: ln -sf libRblas.0.dylib libRblas.dylib\n")
cat("  * Set analysis.threads in analysis_config.json to whichever row above wins.\n")
