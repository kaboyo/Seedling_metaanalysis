#!/usr/bin/env Rscript
# Figure 1 in the Simonin et al. (2022) style: donut map above, study table below,
# composed into a single panel.
#
# The table carries what the map cannot - which study, which author, which host
# species - so a reader can attribute any donut to its source without a second figure.

suppressPackageStartupMessages({
    library(phyloseq); library(ggplot2); library(dplyr); library(tidyr)
    library(stringr); library(ggforce); library(scales)
    library(gridExtra); library(grid); library(patchwork)
    library(ggsci)
})

ps <- readRDS("analysis_results/setup/ps_clean.rds")
md <- as(sample_data(ps), "data.frame")

tidy_country <- function(x) str_trim(str_replace(as.character(x), ":.*$", ""))
tidy_ref <- function(x) {
    x <- as.character(x)
    # 33 of 1,886 Author values are invalid UTF-8. The stray byte is 0x96, which is
    # "n-tilde" in Mac Roman (in latin-1 it is unassigned, so the old latin-1 path
    # dropped it and rendered "Acuna" as "Acua"). Decode only the broken ones.
    bad <- !validUTF8(x)
    x[bad] <- iconv(x[bad], from = "macroman", to = "UTF-8")
    # Take everything up to the first underscore rather than [A-Za-z]+: the latter is
    # ASCII-only and truncated the now-correctly-decoded "Acuna" at the n-tilde.
    surname <- str_replace(x, "^([^_]+).*", "\\1")
    year <- str_extract(x, "(19|20)\\d{2}")
    ifelse(is.na(year), surname, paste0(surname, " et al. ", year))
}

md <- md |>
    mutate(Country = case_when(str_detect(tidy_country(Geography), "Korea") ~ "South Korea",
                               .default = tidy_country(Geography)),
           Reference = tidy_ref(Author),
           Developmental_Stage = factor(as.character(Developmental_Stage),
                                        levels = c("Seeds", "Seedlings")))


# ─────────────────────────────────────────────────────────────────────────────
# FIGURE LEGENDS
#
# Deliberately NOT drawn into the image. Journals require legends in the manuscript
# text, and production desks routinely reject figures with a title or caption baked
# into the artwork. The figure carries only panel tags (a, b) and the colour key;
# the prose below is what goes under it in the manuscript, and is also written to
# analysis_results/tables/figure_legends.md for pasting.
#
# Each entry names the FILE it belongs to and which PANEL each sentence describes.
# ─────────────────────────────────────────────────────────────────────────────

FIGURE_LEGENDS <- list(
  `Figure 1` = list(
    file  = "analysis_results/figures/fig1_geographic_distribution.tiff",
    title = "Global distribution of the compiled seed and seedling microbiome dataset.",
    panels = c(
      a = paste(
        "World map of sample provenance. Each ring is centred on a sampled country;",
        "ring AREA is proportional to the number of samples (radius scales with the",
        "square root of n), and ring segments give the split between seed and seedling",
        "samples. The value inside a ring is its total sample count; counts for small",
        "countries are given in the country label instead. Rings for Denmark, Italy,",
        "Japan, South Korea and New Zealand are offset into open water to avoid",
        "overlap and are connected to their country by a dotted leader line."),
      b = paste(
        "Study composition of the dataset. One row per BioProject, giving the",
        "reference, country of origin, host species (abbreviated to genus initial),",
        "and the number of seed and seedling samples contributing to the analysis.")
    ),
    footer = paste(
      "Counts are samples retained after quality filtering (n = 1,886 of 2,457 in the",
      "compiled metadata). Colours follow the Nature Publishing Group palette.")
  )
)

write_figure_legends <- function(legends, path) {
    lines <- c("# Figure legends", "")
    for (nm in names(legends)) {
        L <- legends[[nm]]
        lines <- c(lines, sprintf("## %s", nm), "",
                   sprintf("*File:* `%s`", L$file), "",
                   sprintf("**%s %s**", nm, L$title), "")
        for (pn in names(L$panels)) {
            lines <- c(lines, sprintf("**%s**, %s", pn, L$panels[[pn]]), "")
        }
        lines <- c(lines, L$footer, "")
    }
    writeLines(lines, path)
    invisible(path)
}

# ── Panel A: donut map ───────────────────────────────────────────────────────
counts <- md |> dplyr::count(Country, Developmental_Stage, name = "n")
totals <- counts |> summarise(total = sum(n), .by = Country)

world <- map_data("world")
centroids <- world |>
    dplyr::count(region, group, name = "pts") |>
    slice_max(pts, n = 1, by = region) |>
    inner_join(world, by = c("region", "group")) |>
    summarise(lon = mean(range(long)), lat = mean(range(lat)), .by = region) |>
    rename(Country = region)

nudge <- tibble::tribble(~Country, ~dx, ~dy,
    "Denmark", -8, 20, "Italy", 2, -26, "Japan", 26, -6,
    "South Korea", 4, -22, "New Zealand", 14, -10)

donut <- totals |>
    inner_join(centroids, by = "Country") |>
    left_join(nudge, by = "Country") |>
    mutate(dx = coalesce(dx, 0), dy = coalesce(dy, 0),
           px = lon + dx, py = lat + dy,
           r = 3.2 + 10.5 * sqrt(total / max(total)))

arcs <- counts |>
    inner_join(donut, by = "Country") |>
    arrange(Country, Developmental_Stage) |>
    mutate(frac = n / total, .by = Country) |>
    mutate(end = 2 * pi * cumsum(frac), start = lag(end, default = 0), .by = Country)

# Nature Publishing Group palette (ggsci::pal_npg). Deep navy vs vermillion: both
# fully saturated, high contrast, and distinguishable under deuteranopia.
STAGE <- c(Seeds = "#3C5488", Seedlings = "#E64B35")
NAT_FONT <- "Helvetica"   # Nature specifies Helvetica or Arial

p_map <- ggplot() +
    geom_polygon(data = world, aes(long, lat, group = group),
                 fill = "grey93", colour = "white", linewidth = 0.12) +
    geom_segment(data = filter(donut, dx != 0 | dy != 0),
                 aes(lon, lat, xend = px, yend = py),
                 colour = "grey45", linewidth = 0.4, linetype = "dotted") +
    geom_point(data = filter(donut, dx != 0 | dy != 0), aes(lon, lat),
               size = 0.5, colour = "grey45") +
    geom_arc_bar(data = arcs,
                 aes(x0 = px, y0 = py, r0 = r * 0.45, r = r,
                     start = start, end = end, fill = Developmental_Stage),
                 colour = "white", linewidth = 0.2) +
    geom_text(data = filter(donut, r >= 6), aes(px, py, label = comma(total)),
              size = 3.1, fontface = "bold", colour = "grey10", family = NAT_FONT) +
    geom_text(data = donut,
              aes(px, py - r - 3.2,
                  label = ifelse(r >= 6, Country, paste0(Country, " (", total, ")"))),
              size = 3.3, colour = "grey15", vjust = 1, family = NAT_FONT) +
    scale_fill_manual(values = STAGE, name = NULL, breaks = c("Seeds", "Seedlings")) +
    coord_quickmap(ylim = c(-58, 84)) +
    theme_void(base_size = 12, base_family = NAT_FONT) +
    theme(plot.background = element_rect(fill = "white", colour = NA),
          legend.position = "bottom",
          legend.text = element_text(size = 12, colour = "grey10", family = NAT_FONT),
          legend.key.size = unit(13, "pt"),
          plot.margin = margin(2, 2, 2, 2))

# ── Panel B: study table ─────────────────────────────────────────────────────
# Species are abbreviated to "G. species" so a 10-species study still fits one cell.
abbrev <- function(s) {
    parts <- str_split(s, " ", simplify = TRUE)
    ifelse(ncol(parts) >= 2 & parts[, 2] != "",
           paste0(str_sub(parts[, 1], 1, 1), ". ", parts[, 2]), s)
}

tab <- md |>
    summarise(Reference = paste(sort(unique(Reference)), collapse = "; "),
              Country   = paste(sort(unique(Country)), collapse = ", "),
              Species   = paste(sort(unique(abbrev(Scientific_Name))), collapse = ", "),
              Seeds     = sum(Developmental_Stage == "Seeds"),
              Seedlings = sum(Developmental_Stage == "Seedlings"),
              n         = dplyr::n(),
              .by = study_alias) |>
    arrange(desc(n)) |>
    mutate(Country = str_wrap(Country, 26),
           Species = str_wrap(Species, 42),
           across(c(Seeds, Seedlings, n), comma)) |>
    rename(`Project ID` = study_alias, `Host species` = Species)

tt <- ttheme_minimal(
    base_size = 9.6,
    core = list(fg_params = list(hjust = 0, x = 0.02, lineheight = 1.0, fontfamily = NAT_FONT),
                bg_params = list(fill = c("white", "grey97"), col = NA)),
    colhead = list(fg_params = list(fontface = "bold", hjust = 0, x = 0.02, fontfamily = NAT_FONT),
                   bg_params = list(fill = "grey90", col = NA)))

p_tab <- tableGrob(tab, rows = NULL, theme = tt)

fig1 <- (p_map / wrap_elements(p_tab)) +
    plot_layout(heights = c(1.55, 1)) +
    # Panel tags only. No title, no caption - see FIGURE_LEGENDS above.
    plot_annotation(
        tag_levels = "a",
        theme = theme(
            plot.background = element_rect(fill = "white", colour = NA),
            plot.tag = element_text(face = "bold", size = 16, family = NAT_FONT)))

ggsave("analysis_results/figures/fig1_geographic_distribution.tiff", fig1,
       width = 13, height = 10, dpi = 300, compression = "lzw", bg = "white")

write_figure_legends(FIGURE_LEGENDS, "analysis_results/tables/figure_legends.md")
cat("\nlegend written to analysis_results/tables/figure_legends.md\n")

cat("\n=== table ===\n")
for (i in seq_len(nrow(tab))) {
    cat(sprintf("  %-12s %-22s %-24s %-46s %5s %5s %6s\n",
        tab$`Project ID`[i], tab$Reference[i],
        str_replace_all(tab$Country[i], "\n", "/"),
        str_replace_all(tab$`Host species`[i], "\n", " "),
        tab$Seeds[i], tab$Seedlings[i], tab$n[i]))
}
cat("\nwrote analysis_results/figures/fig1_geographic_distribution.tiff\n")
