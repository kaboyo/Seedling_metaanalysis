#!/usr/bin/env Rscript
# Publication-ready metadata overview for the seed microbiome meta-analysis.
#
#   Rscript tools/make_metadata_overview.R [analysis_config.json]
#
# One row per study, which is the unit a reader needs: study identity is the main
# confounder in this compilation, so sample counts only mean something alongside how
# many studies and species they came from.
#
# Reports the FILTERED dataset (what the analysis actually used), with the pre-filter
# totals in the footnote - quoting raw metadata counts in a table of analysed data is
# the most common way these tables mislead.

suppressPackageStartupMessages({
    library(phyloseq)
    library(dplyr)
    library(tidyr)
    library(readr)
    library(stringr)
    library(jsonlite)
})

args <- commandArgs(trailingOnly = TRUE)
config_path <- if (length(args)) args[1] else "analysis_config.json"
config <- fromJSON(config_path)
base_dir <- dirname(normalizePath(config_path))
res <- function(...) file.path(normalizePath(file.path(base_dir, config$outputs$directory)), ...)

ps <- readRDS(res("setup", "ps_clean.rds"))
md <- as(sample_data(ps), "data.frame")
md$sample_id <- rownames(md)
md$reads <- sample_sums(ps)
md$observed <- phyloseq::estimate_richness(ps, measures = "Observed")$Observed

# Author strings carry a DOI suffix and mojibake from the latin-1 fallback; strip to
# "Surname et al. YEAR" so the column is citable.
tidy_ref <- function(x) {
    x <- iconv(as.character(x), from = "", to = "UTF-8", sub = "")
    surname <- str_replace(x, "^([A-Za-z]+).*", "\\1")
    year <- str_extract(x, "(19|20)\\d{2}")
    ifelse(is.na(year), surname, paste0(surname, " et al. ", year))
}

# Geography values include sub-national detail ("South Korea: Gyeonggi-do (seed)");
# keep the country for the table and note the rest is preserved in the raw metadata.
tidy_country <- function(x) {
    x <- str_replace(x, ":.*$", "")
    str_trim(x)
}

overview <- md |>
    mutate(Reference = tidy_ref(Author),
           Country = tidy_country(Geography)) |>
    summarise(
        Reference   = paste(sort(unique(Reference)), collapse = "; "),
        Country     = paste(sort(unique(Country)), collapse = "; "),
        n_species   = n_distinct(Scientific_Name),
        Species     = paste(sort(unique(Scientific_Name)), collapse = "; "),
        Seeds       = sum(Developmental_Stage == "Seeds"),
        Seedlings   = sum(Developmental_Stage == "Seedlings"),
        Total       = dplyr::n(),
        median_reads = round(median(reads)),
        median_asvs  = round(median(observed)),
        .by = study_alias) |>
    arrange(desc(Total)) |>
    rename(Study = study_alias)

total_row <- tibble(
    Study = "All studies",
    Reference = sprintf("%d references", n_distinct(tidy_ref(md$Author))),
    Country = sprintf("%d countries", n_distinct(tidy_country(md$Geography))),
    n_species = n_distinct(md$Scientific_Name),
    Species = "-",
    Seeds = sum(md$Developmental_Stage == "Seeds"),
    Seedlings = sum(md$Developmental_Stage == "Seedlings"),
    Total = nrow(md),
    median_reads = round(median(md$reads)),
    median_asvs = round(median(md$observed)))

out <- bind_rows(overview, total_row)
write_csv(out, res("tables", "metadata_overview_publication.csv"))

# ── Markdown version, ready to paste into a manuscript ───────────────────────
fmt <- function(x) formatC(x, format = "d", big.mark = ",")
disp <- out |>
    mutate(Species = ifelse(n_species > 3 & Study != "All studies",
                            sprintf("%d species", n_species), Species),
           across(c(Seeds, Seedlings, Total, median_reads, median_asvs), fmt)) |>
    select(Study, Reference, Country, `Host species` = Species,
           Seeds, Seedlings, Total,
           `Median reads` = median_reads, `Median ASVs` = median_asvs)

lines <- c(
    "Table 1. Metadata overview for the compiled seed and seedling microbiome dataset.",
    "",
    paste0("| ", paste(names(disp), collapse = " | "), " |"),
    paste0("|", paste(rep("---", ncol(disp)), collapse = "|"), "|"),
    apply(disp, 1, \(r) paste0("| ", paste(r, collapse = " | "), " |")),
    "",
    sprintf(paste("Samples are those retained after quality filtering (n = %s of %s in the",
                  "raw metadata; %d ASVs retained of %d). Median reads and median ASVs are",
                  "per sample. Sub-national location is preserved in the raw metadata but",
                  "collapsed to country here."),
            fmt(nrow(md)), "2,457", ntaxa(ps), 129070L))

writeLines(lines, res("tables", "metadata_overview_publication.md"))

cat("wrote:\n")
cat("  ", res("tables", "metadata_overview_publication.csv"), "\n")
cat("  ", res("tables", "metadata_overview_publication.md"), "\n\n")
cat(paste(lines, collapse = "\n"), "\n")
